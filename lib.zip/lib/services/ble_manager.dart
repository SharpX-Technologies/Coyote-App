
// lib/ble_manager.dart
import 'dart:async';
import 'dart:convert';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';

class BleManager {
  BleManager({this.onDisconnected});

  static const String NUS_SERVICE_UUID = "6E400001-B5A3-F393-E0A9-E50E24DCCA9E";
  static const String NUS_TX_CHAR_UUID = "6E400003-B5A3-F393-E0A9-E50E24DCCA9E";
  static const String NUS_RX_CHAR_UUID = "6E400002-B5A3-F393-E0A9-E50E24DCCA9E";

  BluetoothDevice? _device;
  BluetoothCharacteristic? _txChar; // Receive from nRF
  BluetoothCharacteristic? _rxChar; // Send to nRF
  bool _manualDisconnect = false;

  // ── Fixed: track subscriptions so they can be cancelled ──────────────────
  StreamSubscription? _notificationSubscription;
  StreamSubscription? _connectionStateSubscription;
  // ─────────────────────────────────────────────────────────────────────────

  final StreamController<String> _messageController =
      StreamController<String>.broadcast();

  Stream<String> get messageStream => _messageController.stream;
  bool get isConnected => _device != null;

  final void Function()? onDisconnected;

  // ─── Scan ────────────────────────────────────────────────────────────────

  Stream<List<ScanResult>> startScan({
    Duration timeout = const Duration(seconds: 10),
  }) {
    FlutterBluePlus.startScan(
      withServices: [Guid(NUS_SERVICE_UUID)],
      timeout: timeout,
    );
    return FlutterBluePlus.scanResults;
  }

  void stopScan() => FlutterBluePlus.stopScan();

  // ─── Connect ─────────────────────────────────────────────────────────────

  Future<void> connect(BluetoothDevice device) async {
    
    // try {
      await device.connect(license: License.free);
      _device = device;
    // } catch (err) {
    //   _device = null;
    //   print("error connect manager");
    // }

    // ── Fixed: cancel old connection state subscription before new one ─────
    await _connectionStateSubscription?.cancel();
    _connectionStateSubscription = device.connectionState.listen((state) {
      if (state == BluetoothConnectionState.disconnected) {
        _device = null;
        _txChar = null;
        _rxChar = null;
        if (_manualDisconnect == false) {
          onDisconnected?.call();
        }
      }
    });
    // ─────────────────────────────────────────────────────────────────────────

    await _discoverServices();
  }

  Future<void> disconnect() async {
    _manualDisconnect = true;
    // ── Fixed: cancel subscriptions before disconnecting ──────────────────
    await _notificationSubscription?.cancel();
    _notificationSubscription = null;
    await _connectionStateSubscription?.cancel();
    _connectionStateSubscription = null;
    // ─────────────────────────────────────────────────────────────────────────
    await _device?.disconnect();
    _manualDisconnect = false;
    _device = null;
    _txChar = null;
    _rxChar = null;
  }

  /// Clears connection state without disconnecting or invoking onDisconnected.
  /// Use when Bluetooth adapter is turned off and all connections are lost.
  void clearConnection() {
    // ── Fixed: cancel subscriptions on clear ─────────────────────────────
    _notificationSubscription?.cancel();
    _notificationSubscription = null;
    _connectionStateSubscription?.cancel();
    _connectionStateSubscription = null;
    // ─────────────────────────────────────────────────────────────────────────
    _device = null;
    _txChar = null;
    _rxChar = null;
  }

  // ─── Discover Services & Characteristics ─────────────────────────────────

  Future<void> _discoverServices() async {
    if (_device == null) return;

    List<BluetoothService> services = await _device!.discoverServices();

    for (BluetoothService service in services) {
      if (service.uuid.toString().toUpperCase() == NUS_SERVICE_UUID) {
        for (BluetoothCharacteristic char in service.characteristics) {
          String uuid = char.uuid.toString().toUpperCase();

          if (uuid == NUS_TX_CHAR_UUID) {
            _txChar = char;
            await _subscribeToNotifications();
          }

          if (uuid == NUS_RX_CHAR_UUID) {
            _rxChar = char;
          }
        }
      }
    }
  }

  // ─── Receive Messages (nRF → App) ────────────────────────────────────────

  Future<void> _subscribeToNotifications() async {
    if (_txChar == null) return;

    await _txChar!.setNotifyValue(true);

    // ── Fixed: use onValueReceived (scoped to this device instance) instead
    // of lastValueStream (global/shared across ALL devices with same UUID).
    // lastValueStream was causing left/right data to mix randomly.
    // Also cancel any previous subscription first to prevent stacking.
    await _notificationSubscription?.cancel();
    _notificationSubscription = _txChar!.onValueReceived.listen((value) {
      if (value.isNotEmpty) {
        String message = utf8.decode(value);
        _messageController.add(message);
      }
    });
    // ─────────────────────────────────────────────────────────────────────────
  }

  // ─── Send Messages (App → nRF) ────────────────────────────────────────

  Future<void> sendMessage(String message) async {
    if (_rxChar == null) throw Exception("Not connected or RX char not found");

    List<int> bytes = utf8.encode(message);

    const int chunkSize = 20;
    for (int i = 0; i < bytes.length; i += chunkSize) {
      // Re-check on each iteration — device may have dropped mid-send
      if (_rxChar == null) throw Exception("Disconnected mid-send");

      int end = (i + chunkSize < bytes.length) ? i + chunkSize : bytes.length;
      try {
        await _rxChar!.write(bytes.sublist(i, end), withoutResponse: false);
      } on Exception catch (e) {
        throw Exception("Send failed (device may have disconnected): $e");
      }
    }
  }

  Future<void> sendBytes(List<int> bytes) async {
    if (_rxChar == null) throw Exception("Not connected");
    try {
      await _rxChar!.write(bytes, withoutResponse: false);
    } on Exception catch (e) {
      throw Exception("Send failed (device may have disconnected): $e");
    }
  }

  void dispose() {
    _notificationSubscription?.cancel();
    _connectionStateSubscription?.cancel();
    _messageController.close();
  }
}
