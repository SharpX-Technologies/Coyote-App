// // // // // import 'dart:async';

// // // // // import 'package:coyote_app/components/action_widget.dart';
// // // // // import 'package:coyote_app/components/vacuum_gauge_slider.dart';
// // // // // import 'package:coyote_app/controller/ble_controller.dart';
// // // // // import 'package:flutter/material.dart';
// // // // // import 'package:flutter_svg/svg.dart';
// // // // // import 'package:get/get.dart';
// // // // // import '../theme/app_colors.dart';
// // // // // import '../components/components.dart';

// // // // // /// Full Coyote control screen: Left/Right, circular gauge, Sit/Walk/Run,
// // // // // /// Bluetooth & Battery status, and Turn Off button.
// // // // // class ControlScreen extends StatefulWidget {
// // // // //   const ControlScreen({super.key});

// // // // //   @override
// // // // //   State<ControlScreen> createState() => _ControlScreenState();
// // // // // }

// // // // // class _ControlScreenState extends State<ControlScreen> {
// // // // //   final BleController _bleController = Get.find<BleController>();
// // // // //   int _sideIndex = 0;
// // // // //   int _activityIndex = 0;
// // // // //   int _targetVacuum = 12;
// // // // //   double _actualVacuum = 8.4;

// // // // //   @override
// // // // //   Widget build(BuildContext context) {
// // // // //     return GetBuilder<BleController>(
// // // // //       init: _bleController,
// // // // //       builder: (_) {
// // // // //         return Scaffold(
// // // // //           body: CoyoteBackground(
// // // // //             child: SafeArea(
// // // // //               child: Padding(
// // // // //                 padding: const EdgeInsets.symmetric(horizontal: 24),
// // // // //                 child: Column(
// // // // //                   crossAxisAlignment: CrossAxisAlignment.stretch,
// // // // //                   children: [
// // // // //                     SizedBox(height: 20),
// // // // //                     _buildHeader(),
// // // // //                     const SizedBox(height: 28),
// // // // //                     SegmentedControl<String>(
// // // // //                       options: [
// // // // //                         SegmentOption(
// // // // //                           label: 'Left',
// // // // //                           imageUri: _sideIndex == 0
// // // // //                               ? "assets/images/left_white.svg"
// // // // //                               : "assets/images/left_grey.svg",
// // // // //                           isConnected: true,
// // // // //                         ),
// // // // //                         SegmentOption(
// // // // //                           label: 'Right',
// // // // //                           imageUri: _sideIndex == 1
// // // // //                               ? "assets/images/right_white.svg"
// // // // //                               : "assets/images/right_grey.svg",
// // // // //                           isConnected: true,
// // // // //                         ),
// // // // //                       ],
// // // // //                       selectedIndex: _sideIndex,
// // // // //                       onChanged: (i) => setState(() => _sideIndex = i),
// // // // //                     ),
// // // // //                     const SizedBox(height: 20),

// // // // //                     Expanded(
// // // // //                       child:
// // // // //                           _bleController.isConnected(
// // // // //                             deviceSide: _sideIndex == 0
// // // // //                                 ? DeviceSide.left
// // // // //                                 : DeviceSide.right,
// // // // //                           )
// // // // //                           ? VacuumGaugeSlider(
// // // // //                               minValue: 0,
// // // // //                               maxValue: 20,
// // // // //                               currentValue: _bleController
// // // // //                                   .getCurrentPressure(
// // // // //                                     _sideIndex == 0
// // // // //                                         ? DeviceSide.left
// // // // //                                         : DeviceSide.right,
// // // // //                                   )
// // // // //                                   .toDouble(),
// // // // //                               targetValue: _bleController
// // // // //                                   .getTargetPressure(
// // // // //                                     _sideIndex == 0
// // // // //                                         ? DeviceSide.left
// // // // //                                         : DeviceSide.right,
// // // // //                                   )
// // // // //                                   .toDouble(),
// // // // //                               onChanged: (value) async {
// // // // //                                 final side = _sideIndex == 0
// // // // //                                     ? DeviceSide.left
// // // // //                                     : DeviceSide.right;
// // // // //                                 _bleController.removePreset(side);
// // // // //                                 _bleController.setGuage(
// // // // //                                   pressure: value.toInt(),
// // // // //                                   deviceSide: side,
// // // // //                                 );
// // // // //                               },
// // // // //                             )
// // // // //                           : SvgPicture.asset("assets/images/value_bar.svg"),
// // // // //                     ),
// // // // //                     Container(
// // // // //                       height: 58,

// // // // //                       decoration: BoxDecoration(
// // // // //                         color: AppColors.segmentContainer,
// // // // //                         borderRadius: BorderRadius.circular(12),
// // // // //                         boxShadow: [
// // // // //                           BoxShadow(
// // // // //                             color: Colors.black.withValues(alpha: 0.2),
// // // // //                             blurRadius: 4,
// // // // //                             offset: const Offset(0, 1),
// // // // //                           ),
// // // // //                         ],
// // // // //                       ),
// // // // //                       child: Row(
// // // // //                         // mainAxisAlignment: MainAxisAlignment.spaceBetween,
// // // // //                         children: [
// // // // //                           ActionWidget(
// // // // //                             imageUri:
// // // // //                                 _bleController.getSelectedPreset(
// // // // //                                           _sideIndex == 0
// // // // //                                               ? DeviceSide.left
// // // // //                                               : DeviceSide.right,
// // // // //                                         ) ==
// // // // //                                         Presets.sit &&
// // // // //                                     _bleController.isConnected(
// // // // //                                       deviceSide: _sideIndex == 0
// // // // //                                           ? DeviceSide.left
// // // // //                                           : DeviceSide.right,
// // // // //                                     )
// // // // //                                 ? "assets/images/sit_white.svg"
// // // // //                                 : "assets/images/sit_grey.svg",
// // // // //                             label: "Sit",
// // // // //                             isSelected:
// // // // //                                 _bleController.getSelectedPreset(
// // // // //                                       _sideIndex == 0
// // // // //                                           ? DeviceSide.left
// // // // //                                           : DeviceSide.right,
// // // // //                                     ) ==
// // // // //                                     Presets.sit &&
// // // // //                                 _bleController.isConnected(
// // // // //                                   deviceSide: _sideIndex == 0
// // // // //                                       ? DeviceSide.left
// // // // //                                       : DeviceSide.right,
// // // // //                                 ),
// // // // //                             onPress: () => _onPresetPressed(Presets.sit),
// // // // //                           ),
// // // // //                           ActionWidget(
// // // // //                             imageUri:
// // // // //                                 _bleController.getSelectedPreset(
// // // // //                                           _sideIndex == 0
// // // // //                                               ? DeviceSide.left
// // // // //                                               : DeviceSide.right,
// // // // //                                         ) ==
// // // // //                                         Presets.walk &&
// // // // //                                     _bleController.isConnected(
// // // // //                                       deviceSide: _sideIndex == 0
// // // // //                                           ? DeviceSide.left
// // // // //                                           : DeviceSide.right,
// // // // //                                     )
// // // // //                                 ? "assets/images/walk_white.svg"
// // // // //                                 : "assets/images/walk_grey.svg",
// // // // //                             label: "Walk",
// // // // //                             isSelected:
// // // // //                                 _bleController.getSelectedPreset(
// // // // //                                       _sideIndex == 0
// // // // //                                           ? DeviceSide.left
// // // // //                                           : DeviceSide.right,
// // // // //                                     ) ==
// // // // //                                     Presets.walk &&
// // // // //                                 _bleController.isConnected(
// // // // //                                   deviceSide: _sideIndex == 0
// // // // //                                       ? DeviceSide.left
// // // // //                                       : DeviceSide.right,
// // // // //                                 ),
// // // // //                             onPress: () => _onPresetPressed(Presets.walk),
// // // // //                           ),
// // // // //                           ActionWidget(
// // // // //                             imageUri:
// // // // //                                 _bleController.getSelectedPreset(
// // // // //                                           _sideIndex == 0
// // // // //                                               ? DeviceSide.left
// // // // //                                               : DeviceSide.right,
// // // // //                                         ) ==
// // // // //                                         Presets.run &&
// // // // //                                     _bleController.isConnected(
// // // // //                                       deviceSide: _sideIndex == 0
// // // // //                                           ? DeviceSide.left
// // // // //                                           : DeviceSide.right,
// // // // //                                     )
// // // // //                                 ? "assets/images/run_white.svg"
// // // // //                                 : "assets/images/run_grey.svg",
// // // // //                             label: "Run",
// // // // //                             isSelected:
// // // // //                                 _bleController.getSelectedPreset(
// // // // //                                       _sideIndex == 0
// // // // //                                           ? DeviceSide.left
// // // // //                                           : DeviceSide.right,
// // // // //                                     ) ==
// // // // //                                     Presets.run &&
// // // // //                                 _bleController.isConnected(
// // // // //                                   deviceSide: _sideIndex == 0
// // // // //                                       ? DeviceSide.left
// // // // //                                       : DeviceSide.right,
// // // // //                                 ),
// // // // //                             onPress: () => _onPresetPressed(Presets.run),
// // // // //                           ),
// // // // //                         ],
// // // // //                       ),
// // // // //                     ),

// // // // //                     const SizedBox(height: 32),
// // // // //                     SizedBox(
// // // // //                       height: 76,
// // // // //                       child: Row(
// // // // //                         children: [
// // // // //                           Expanded(
// // // // //                             child: StatusCard(
// // // // //                               title: 'Bluetooth',
// // // // //                               isConnected: _bleController.isConnected(
// // // // //                                 deviceSide: _sideIndex == 0
// // // // //                                     ? DeviceSide.left
// // // // //                                     : DeviceSide.right,
// // // // //                               ),
// // // // //                               subtitle:
// // // // //                                   _bleController.isConnected(
// // // // //                                     deviceSide: _sideIndex == 0
// // // // //                                         ? DeviceSide.left
// // // // //                                         : DeviceSide.right,
// // // // //                                   )
// // // // //                                   ? 'Connected'
// // // // //                                   : "Disconnected",
// // // // //                               imageUri: "assets/images/bluetooth.svg",
// // // // //                               onTap: _onBluetoothTap,
// // // // //                             ),
// // // // //                           ),
// // // // //                           const SizedBox(width: 8),
// // // // //                           Expanded(
// // // // //                             child: StatusCard(
// // // // //                               title: 'Battery',
// // // // //                               isConnected: _bleController.isConnected(
// // // // //                                 deviceSide: _sideIndex == 0
// // // // //                                     ? DeviceSide.left
// // // // //                                     : DeviceSide.right,
// // // // //                               ),
// // // // //                               imageUri: "assets/images/battery.svg",
// // // // //                               trailing:
// // // // //                                   _bleController.isConnected(
// // // // //                                     deviceSide: _sideIndex == 0
// // // // //                                         ? DeviceSide.left
// // // // //                                         : DeviceSide.right,
// // // // //                                   )
// // // // //                                   ? Row(
// // // // //                                       mainAxisSize: MainAxisSize.min,
// // // // //                                       children: [
// // // // //                                         if (_bleController
// // // // //                                                 .getBatteryInfo(
// // // // //                                                   _sideIndex == 0
// // // // //                                                       ? DeviceSide.left
// // // // //                                                       : DeviceSide.right,
// // // // //                                                 )
// // // // //                                                 .chargingStatus ==
// // // // //                                             1) ...[
// // // // //                                           Icon(
// // // // //                                             Icons.bolt,
// // // // //                                             size: 18,
// // // // //                                             color: AppColors.success,
// // // // //                                           ),
// // // // //                                           const SizedBox(width: 4),
// // // // //                                         ],
// // // // //                                         Text(
// // // // //                                           '${_bleController.getBatteryInfo(_sideIndex == 0 ? DeviceSide.left : DeviceSide.right).batteryPercentage.toStringAsFixed(0)}%',
// // // // //                                           style: const TextStyle(
// // // // //                                             fontSize: 15,
// // // // //                                             fontWeight: FontWeight.w600,
// // // // //                                             color: AppColors.success,
// // // // //                                           ),
// // // // //                                         ),
// // // // //                                       ],
// // // // //                                     )
// // // // //                                   : Container(),
// // // // //                               onTap: _onBatteryTap,
// // // // //                             ),
// // // // //                           ),
// // // // //                         ],
// // // // //                       ),
// // // // //                     ),
// // // // //                     const SizedBox(height: 8),
// // // // //                     PrimaryActionButton(
// // // // //                       label:
// // // // //                           _bleController.getPumpStatus(
// // // // //                                 _sideIndex == 0
// // // // //                                     ? DeviceSide.left
// // // // //                                     : DeviceSide.right,
// // // // //                               ) ==
// // // // //                               1
// // // // //                           ? 'Turn Off'
// // // // //                           : 'Turn On',
// // // // //                       icon: Icons.power_settings_new,
// // // // //                       onPressed: _onTurnOff,
// // // // //                       isOn:
// // // // //                           _bleController.getPumpStatus(
// // // // //                             _sideIndex == 0
// // // // //                                 ? DeviceSide.left
// // // // //                                 : DeviceSide.right,
// // // // //                           ) ==
// // // // //                           1,
// // // // //                     ),
// // // // //                     // const SizedBox(height: 20),
// // // // //                   ],
// // // // //                 ),
// // // // //               ),
// // // // //             ),
// // // // //           ),
// // // // //         );
// // // // //       },
// // // // //     );
// // // // //   }

// // // // //   Widget _buildHeader() {
// // // // //     return Row(
// // // // //       children: [
// // // // //         SvgPicture.asset("assets/images/logo.svg"),
// // // // //         // Text(
// // // // //         //   'Coyote',
// // // // //         //   style: TextStyle(
// // // // //         //     fontSize: 24,
// // // // //         //     fontWeight: FontWeight.bold,
// // // // //         //     color: AppColors.textPrimary,
// // // // //         //   ),
// // // // //         // ),
// // // // //         // const SizedBox(width: 4),
// // // // //         // Icon(Icons.pets, color: AppColors.textPrimary, size: 26),
// // // // //       ],
// // // // //     );
// // // // //   }

// // // // //   void _onBluetoothTap() {
// // // // //     // TODO: Open Bluetooth settings or status
// // // // //   }

// // // // //   void _onPresetPressed(Presets preset) {
// // // // //     final side = _sideIndex == 0 ? DeviceSide.left : DeviceSide.right;
// // // // //     if (!_bleController.isConnected(deviceSide: side)) {
// // // // //       _showDisconnectedSnackBar(context);
// // // // //       return;
// // // // //     }
// // // // //     _bleController.ApplyPreset(deviceSide: side, preset: preset);
// // // // //   }

// // // // //   void _onBatteryTap() async {
// // // // //     final side = _sideIndex == 0 ? DeviceSide.left : DeviceSide.right;

// // // // //     if (!_bleController.isConnected(deviceSide: side)) {
// // // // //       _showDisconnectedSnackBar(context);
// // // // //       return;
// // // // //     }

// // // // //     await _bleController.sendMessage(deviceSide: side, message: "7");
// // // // //     if (!context.mounted) return;
// // // // //     _showInfoDialog(context);
// // // // //   }

// // // // //   void _showInfoDialog(BuildContext context) {
// // // // //     final side = _sideIndex == 0 ? DeviceSide.left : DeviceSide.right;
// // // // //     final battery = _bleController.getBatteryInfo(side);
// // // // //     showDialog(
// // // // //       context: context,
// // // // //       builder: (BuildContext context) {
// // // // //         return AlertDialog(
// // // // //           title: const Text('Battery Information'),
// // // // //           content: Column(
// // // // //             mainAxisSize: MainAxisSize.min,
// // // // //             crossAxisAlignment: CrossAxisAlignment.start,
// // // // //             children: [
// // // // //               Text(
// // // // //                 "Charging Status:  ${battery.chargingStatus == 1 ? "Charging" : "Not Charging"}",
// // // // //               ),
// // // // //               const SizedBox(height: 8),
// // // // //               Text('Battery Percentage: ${battery.batteryPercentage}'),
// // // // //               const SizedBox(height: 8),
// // // // //               Text('Battery Voltage: ${battery.batteryVoltage}'),
// // // // //             ],
// // // // //           ),
// // // // //           actions: [
// // // // //             TextButton(
// // // // //               onPressed: () => Navigator.of(context).pop(),
// // // // //               child: const Text('Close'),
// // // // //             ),
// // // // //           ],
// // // // //         );
// // // // //       },
// // // // //     );
// // // // //   }

// // // // //   void _onTurnOff() async {
// // // // //     final side = _sideIndex == 0 ? DeviceSide.left : DeviceSide.right;

// // // // //     if (!_bleController.isConnected(deviceSide: side)) {
// // // // //       _showDisconnectedSnackBar(context);
// // // // //       return;
// // // // //     }

// // // // //     await _bleController.sendMessage(
// // // // //       message: _bleController.getPumpStatus(side) == 1 ? "2" : "1",
// // // // //       deviceSide: side,
// // // // //     );
// // // // //   }

// // // // //   void _showDisconnectedSnackBar(BuildContext context) {
// // // // //     if (!context.mounted) return;
// // // // //     ScaffoldMessenger.of(context).showSnackBar(
// // // // //       const SnackBar(
// // // // //         content: Text(
// // // // //           'Device disconnected. Connect your device from the Pair screen.',
// // // // //         ),
// // // // //         behavior: SnackBarBehavior.floating,
// // // // //       ),
// // // // //     );
// // // // //   }
// // // // // }

// // // // import 'dart:async';

// // // // import 'package:coyote_app/components/action_widget.dart';
// // // // import 'package:coyote_app/components/vacuum_gauge_slider.dart';
// // // // import 'package:coyote_app/controller/ble_controller.dart';
// // // // import 'package:flutter/material.dart';
// // // // import 'package:flutter_svg/svg.dart';
// // // // import 'package:get/get.dart';
// // // // import '../theme/app_colors.dart';
// // // // import '../components/components.dart';

// // // // /// Full Coyote control screen: Left/Right, circular gauge, Sit/Walk/Run,
// // // // /// Bluetooth & Battery status, and Turn Off button.
// // // // class ControlScreen extends StatefulWidget {
// // // //   const ControlScreen({super.key});

// // // //   @override
// // // //   State<ControlScreen> createState() => _ControlScreenState();
// // // // }

// // // // class _ControlScreenState extends State<ControlScreen> {
// // // //   final BleController _bleController = Get.find<BleController>();
// // // //   int _sideIndex = 0;
// // // //   int _activityIndex = 0;
// // // //   int _targetVacuum = 12;
// // // //   double _actualVacuum = 8.4;

// // // //   @override
// // // //   Widget build(BuildContext context) {
// // // //     return GetBuilder<BleController>(
// // // //       init: _bleController,
// // // //       builder: (_) {
// // // //         return Scaffold(
// // // //           body: CoyoteBackground(
// // // //             child: SafeArea(
// // // //               child: Padding(
// // // //                 padding: const EdgeInsets.symmetric(horizontal: 24),
// // // //                 child: Column(
// // // //                   crossAxisAlignment: CrossAxisAlignment.stretch,
// // // //                   children: [
// // // //                     SizedBox(height: 20),
// // // //                     _buildHeader(),
// // // //                     const SizedBox(height: 28),
// // // //                     SegmentedControl<String>(
// // // //                       options: [
// // // //                         SegmentOption(
// // // //                           label: 'Left',
// // // //                           imageUri: _sideIndex == 0
// // // //                               ? "assets/images/left_white.svg"
// // // //                               : "assets/images/left_grey.svg",
// // // //                           isConnected: true,
// // // //                         ),
// // // //                         SegmentOption(
// // // //                           label: 'Right',
// // // //                           imageUri: _sideIndex == 1
// // // //                               ? "assets/images/right_white.svg"
// // // //                               : "assets/images/right_grey.svg",
// // // //                           isConnected: true,
// // // //                         ),
// // // //                       ],
// // // //                       selectedIndex: _sideIndex,
// // // //                       onChanged: (i) => setState(() => _sideIndex = i),
// // // //                     ),
// // // //                     const SizedBox(height: 20),

// // // //                     Expanded(
// // // //                       child:
// // // //                           _bleController.isConnected(
// // // //                             deviceSide: _sideIndex == 0
// // // //                                 ? DeviceSide.left
// // // //                                 : DeviceSide.right,
// // // //                           )
// // // //                           ? Align(
// // // //                               alignment: Alignment.center,
// // // //                               child: VacuumGaugeSlider(
// // // //                                 minValue: 0,
// // // //                                 maxValue: 20,
// // // //                                 currentValue: _bleController
// // // //                                     .getCurrentPressure(
// // // //                                       _sideIndex == 0
// // // //                                           ? DeviceSide.left
// // // //                                           : DeviceSide.right,
// // // //                                     )
// // // //                                     .toDouble(),
// // // //                                 targetValue: _bleController
// // // //                                     .getTargetPressure(
// // // //                                       _sideIndex == 0
// // // //                                           ? DeviceSide.left
// // // //                                           : DeviceSide.right,
// // // //                                     )
// // // //                                     .toDouble(),
// // // //                                 onChanged: (value) async {
// // // //                                   final side = _sideIndex == 0
// // // //                                       ? DeviceSide.left
// // // //                                       : DeviceSide.right;
// // // //                                   _bleController.removePreset(side);
// // // //                                   _bleController.setGuage(
// // // //                                     pressure: value.toInt(),
// // // //                                     deviceSide: side,
// // // //                                   );
// // // //                                 },
// // // //                               ),
// // // //                             )
// // // //                           : SvgPicture.asset("assets/images/value_bar.svg"),
// // // //                     ),
// // // //                     Container(
// // // //                       height: 58,

// // // //                       decoration: BoxDecoration(
// // // //                         color: AppColors.segmentContainer,
// // // //                         borderRadius: BorderRadius.circular(12),
// // // //                         boxShadow: [
// // // //                           BoxShadow(
// // // //                             color: Colors.black.withValues(alpha: 0.2),
// // // //                             blurRadius: 4,
// // // //                             offset: const Offset(0, 1),
// // // //                           ),
// // // //                         ],
// // // //                       ),
// // // //                       child: Row(
// // // //                         // mainAxisAlignment: MainAxisAlignment.spaceBetween,
// // // //                         children: [
// // // //                           ActionWidget(
// // // //                             imageUri:
// // // //                                 _bleController.getSelectedPreset(
// // // //                                           _sideIndex == 0
// // // //                                               ? DeviceSide.left
// // // //                                               : DeviceSide.right,
// // // //                                         ) ==
// // // //                                         Presets.sit &&
// // // //                                     _bleController.isConnected(
// // // //                                       deviceSide: _sideIndex == 0
// // // //                                           ? DeviceSide.left
// // // //                                           : DeviceSide.right,
// // // //                                     )
// // // //                                 ? "assets/images/sit_white.svg"
// // // //                                 : "assets/images/sit_grey.svg",
// // // //                             label: "Sit",
// // // //                             isSelected:
// // // //                                 _bleController.getSelectedPreset(
// // // //                                       _sideIndex == 0
// // // //                                           ? DeviceSide.left
// // // //                                           : DeviceSide.right,
// // // //                                     ) ==
// // // //                                     Presets.sit &&
// // // //                                 _bleController.isConnected(
// // // //                                   deviceSide: _sideIndex == 0
// // // //                                       ? DeviceSide.left
// // // //                                       : DeviceSide.right,
// // // //                                 ),
// // // //                             onPress: () => _onPresetPressed(Presets.sit),
// // // //                           ),
// // // //                           ActionWidget(
// // // //                             imageUri:
// // // //                                 _bleController.getSelectedPreset(
// // // //                                           _sideIndex == 0
// // // //                                               ? DeviceSide.left
// // // //                                               : DeviceSide.right,
// // // //                                         ) ==
// // // //                                         Presets.walk &&
// // // //                                     _bleController.isConnected(
// // // //                                       deviceSide: _sideIndex == 0
// // // //                                           ? DeviceSide.left
// // // //                                           : DeviceSide.right,
// // // //                                     )
// // // //                                 ? "assets/images/walk_white.svg"
// // // //                                 : "assets/images/walk_grey.svg",
// // // //                             label: "Walk",
// // // //                             isSelected:
// // // //                                 _bleController.getSelectedPreset(
// // // //                                       _sideIndex == 0
// // // //                                           ? DeviceSide.left
// // // //                                           : DeviceSide.right,
// // // //                                     ) ==
// // // //                                     Presets.walk &&
// // // //                                 _bleController.isConnected(
// // // //                                   deviceSide: _sideIndex == 0
// // // //                                       ? DeviceSide.left
// // // //                                       : DeviceSide.right,
// // // //                                 ),
// // // //                             onPress: () => _onPresetPressed(Presets.walk),
// // // //                           ),
// // // //                           ActionWidget(
// // // //                             imageUri:
// // // //                                 _bleController.getSelectedPreset(
// // // //                                           _sideIndex == 0
// // // //                                               ? DeviceSide.left
// // // //                                               : DeviceSide.right,
// // // //                                         ) ==
// // // //                                         Presets.run &&
// // // //                                     _bleController.isConnected(
// // // //                                       deviceSide: _sideIndex == 0
// // // //                                           ? DeviceSide.left
// // // //                                           : DeviceSide.right,
// // // //                                     )
// // // //                                 ? "assets/images/run_white.svg"
// // // //                                 : "assets/images/run_grey.svg",
// // // //                             label: "Run",
// // // //                             isSelected:
// // // //                                 _bleController.getSelectedPreset(
// // // //                                       _sideIndex == 0
// // // //                                           ? DeviceSide.left
// // // //                                           : DeviceSide.right,
// // // //                                     ) ==
// // // //                                     Presets.run &&
// // // //                                 _bleController.isConnected(
// // // //                                   deviceSide: _sideIndex == 0
// // // //                                       ? DeviceSide.left
// // // //                                       : DeviceSide.right,
// // // //                                 ),
// // // //                             onPress: () => _onPresetPressed(Presets.run),
// // // //                           ),
// // // //                         ],
// // // //                       ),
// // // //                     ),

// // // //                     const SizedBox(height: 32),
// // // //                     SizedBox(
// // // //                       height: 76,
// // // //                       child: Row(
// // // //                         children: [
// // // //                           Expanded(
// // // //                             child: StatusCard(
// // // //                               title: 'Bluetooth',
// // // //                               isConnected: _bleController.isConnected(
// // // //                                 deviceSide: _sideIndex == 0
// // // //                                     ? DeviceSide.left
// // // //                                     : DeviceSide.right,
// // // //                               ),
// // // //                               subtitle:
// // // //                                   _bleController.isConnected(
// // // //                                     deviceSide: _sideIndex == 0
// // // //                                         ? DeviceSide.left
// // // //                                         : DeviceSide.right,
// // // //                                   )
// // // //                                   ? 'Connected'
// // // //                                   : "UnConnected",
// // // //                               imageUri: "assets/images/bluetooth.svg",
// // // //                               onTap: _onBluetoothTap,
// // // //                             ),
// // // //                           ),
// // // //                           const SizedBox(width: 8),
// // // //                           Expanded(
// // // //                             child: StatusCard(
// // // //                               title: 'Battery',
// // // //                               isConnected: _bleController.isConnected(
// // // //                                 deviceSide: _sideIndex == 0
// // // //                                     ? DeviceSide.left
// // // //                                     : DeviceSide.right,
// // // //                               ),
// // // //                               imageUri: "assets/images/battery.svg",
// // // //                               trailing:
// // // //                                   _bleController.isConnected(
// // // //                                     deviceSide: _sideIndex == 0
// // // //                                         ? DeviceSide.left
// // // //                                         : DeviceSide.right,
// // // //                                   )
// // // //                                   ? Row(
// // // //                                       mainAxisSize: MainAxisSize.min,
// // // //                                       children: [
// // // //                                         if (_bleController
// // // //                                                 .getBatteryInfo(
// // // //                                                   _sideIndex == 0
// // // //                                                       ? DeviceSide.left
// // // //                                                       : DeviceSide.right,
// // // //                                                 )
// // // //                                                 .chargingStatus ==
// // // //                                             1) ...[
// // // //                                           Icon(
// // // //                                             Icons.bolt,
// // // //                                             size: 18,
// // // //                                             color: AppColors.success,
// // // //                                           ),
// // // //                                           const SizedBox(width: 4),
// // // //                                         ],
// // // //                                         Text(
// // // //                                           '${_bleController.getBatteryInfo(_sideIndex == 0 ? DeviceSide.left : DeviceSide.right).batteryPercentage.toStringAsFixed(0)}%',
// // // //                                           style: const TextStyle(
// // // //                                             fontSize: 15,
// // // //                                             fontWeight: FontWeight.w600,
// // // //                                             color: AppColors.success,
// // // //                                           ),
// // // //                                         ),
// // // //                                       ],
// // // //                                     )
// // // //                                   : Container(),
// // // //                               onTap: _onBatteryTap,
// // // //                             ),
// // // //                           ),
// // // //                         ],
// // // //                       ),
// // // //                     ),
// // // //                     const SizedBox(height: 8),
// // // //                     PrimaryActionButton(
// // // //                       label:
// // // //                           _bleController.getPumpStatus(
// // // //                                 _sideIndex == 0
// // // //                                     ? DeviceSide.left
// // // //                                     : DeviceSide.right,
// // // //                               ) ==
// // // //                               1
// // // //                           ? 'Turn Off'
// // // //                           : 'Turn On',
// // // //                       icon: Icons.power_settings_new,
// // // //                       onPressed: _onTurnOff,
// // // //                       isOn:
// // // //                           _bleController.getPumpStatus(
// // // //                             _sideIndex == 0
// // // //                                 ? DeviceSide.left
// // // //                                 : DeviceSide.right,
// // // //                           ) ==
// // // //                           1,
// // // //                     ),
// // // //                     // const SizedBox(height: 20),
// // // //                   ],
// // // //                 ),
// // // //               ),
// // // //             ),
// // // //           ),
// // // //         );
// // // //       },
// // // //     );
// // // //   }

// // // //   Widget _buildHeader() {
// // // //     return Row(
// // // //       children: [
// // // //         SvgPicture.asset("assets/images/logo.svg"),
// // // //         // Text(
// // // //         //   'Coyote',
// // // //         //   style: TextStyle(
// // // //         //     fontSize: 24,
// // // //         //     fontWeight: FontWeight.bold,
// // // //         //     color: AppColors.textPrimary,
// // // //         //   ),
// // // //         // ),
// // // //         // const SizedBox(width: 4),
// // // //         // Icon(Icons.pets, color: AppColors.textPrimary, size: 26),
// // // //       ],
// // // //     );
// // // //   }

// // // //   void _onBluetoothTap() {
// // // //     // TODO: Open Bluetooth settings or status
// // // //   }

// // // //   void _onPresetPressed(Presets preset) {
// // // //     final side = _sideIndex == 0 ? DeviceSide.left : DeviceSide.right;
// // // //     if (!_bleController.isConnected(deviceSide: side)) {
// // // //       _showDisconnectedSnackBar(context);
// // // //       return;
// // // //     }
// // // //     _bleController.ApplyPreset(deviceSide: side, preset: preset);
// // // //   }

// // // //   void _onBatteryTap() async {
// // // //     final side = _sideIndex == 0 ? DeviceSide.left : DeviceSide.right;

// // // //     if (!_bleController.isConnected(deviceSide: side)) {
// // // //       _showDisconnectedSnackBar(context);
// // // //       return;
// // // //     }

// // // //     await _bleController.sendMessage(deviceSide: side, message: "7");
// // // //     if (!context.mounted) return;
// // // //     _showInfoDialog(context);
// // // //   }

// // // //   void _showInfoDialog(BuildContext context) {
// // // //     final side = _sideIndex == 0 ? DeviceSide.left : DeviceSide.right;
// // // //     final battery = _bleController.getBatteryInfo(side);
// // // //     showDialog(
// // // //       context: context,
// // // //       builder: (BuildContext context) {
// // // //         return AlertDialog(
// // // //           title: const Text('Battery Information'),
// // // //           content: Column(
// // // //             mainAxisSize: MainAxisSize.min,
// // // //             crossAxisAlignment: CrossAxisAlignment.start,
// // // //             children: [
// // // //               Text(
// // // //                 "Charging Status:  ${battery.chargingStatus == 1 ? "Charging" : "Not Charging"}",
// // // //               ),
// // // //               const SizedBox(height: 8),
// // // //               Text('Battery Percentage: ${battery.batteryPercentage}'),
// // // //               const SizedBox(height: 8),
// // // //               Text('Battery Voltage: ${battery.batteryVoltage}'),
// // // //             ],
// // // //           ),
// // // //           actions: [
// // // //             TextButton(
// // // //               onPressed: () => Navigator.of(context).pop(),
// // // //               child: const Text('Close'),
// // // //             ),
// // // //           ],
// // // //         );
// // // //       },
// // // //     );
// // // //   }

// // // //   void _onTurnOff() async {
// // // //     final side = _sideIndex == 0 ? DeviceSide.left : DeviceSide.right;

// // // //     if (!_bleController.isConnected(deviceSide: side)) {
// // // //       _showDisconnectedSnackBar(context);
// // // //       return;
// // // //     }

// // // //     await _bleController.sendMessage(
// // // //       message: _bleController.getPumpStatus(side) == 1 ? "2" : "1",
// // // //       deviceSide: side,
// // // //     );
// // // //   }

// // // //   void _showDisconnectedSnackBar(BuildContext context) {
// // // //     if (!context.mounted) return;
// // // //     final messenger = ScaffoldMessenger.of(context);
// // // //     messenger.clearSnackBars();
// // // //     messenger.showSnackBar(
// // // //       const SnackBar(
// // // //         content: Text(
// // // //           'Device disconnected. Connect your device from the Pair screen.',
// // // //         ),
// // // //         behavior: SnackBarBehavior.floating,
// // // //       ),
// // // //     );
// // // //   }
// // // // }

// // // // import 'dart:async';

// // // // import 'package:coyote_app/components/action_widget.dart';
// // // // import 'package:coyote_app/components/vacuum_gauge_slider.dart';
// // // // import 'package:coyote_app/controller/ble_controller.dart';
// // // // import 'package:flutter/material.dart';
// // // // import 'package:flutter_svg/svg.dart';
// // // // import 'package:get/get.dart';
// // // // import '../theme/app_colors.dart';
// // // // import '../components/components.dart';

// // // // /// Full Coyote control screen: Left/Right, circular gauge, Sit/Walk/Run,
// // // // /// Bluetooth & Battery status, and Turn Off button.
// // // // class ControlScreen extends StatefulWidget {
// // // //   const ControlScreen({super.key});

// // // //   @override
// // // //   State<ControlScreen> createState() => _ControlScreenState();
// // // // }

// // // // class _ControlScreenState extends State<ControlScreen> {
// // // //   final BleController _bleController = Get.find<BleController>();
// // // //   int _sideIndex = 0;
// // // //   int _activityIndex = 0;
// // // //   int _targetVacuum = 12;
// // // //   double _actualVacuum = 8.4;

// // // //   @override
// // // //   void initState() {
// // // //     super.initState();
// // // //     // Auto-select the side when exactly one device is connected on startup.
// // // //     // If both or neither are connected, leave _sideIndex as-is so the user
// // // //     // can switch manually.
// // // //     WidgetsBinding.instance.addPostFrameCallback((_) {
// // // //       final leftConnected =
// // // //           _bleController.isConnected(deviceSide: DeviceSide.left);
// // // //       final rightConnected =
// // // //           _bleController.isConnected(deviceSide: DeviceSide.right);
// // // //       if (leftConnected && !rightConnected) {
// // // //         setState(() => _sideIndex = 0);
// // // //       } else if (rightConnected && !leftConnected) {
// // // //         setState(() => _sideIndex = 1);
// // // //       }
// // // //       // Both connected or neither connected → keep _sideIndex = 0 (default)
// // // //       // and let the user choose manually via the SegmentedControl.
// // // //     });
// // // //   }

// // // //   @override
// // // //   Widget build(BuildContext context) {
// // // //     return GetBuilder<BleController>(
// // // //       init: _bleController,
// // // //       builder: (_) {
// // // //         return Scaffold(
// // // //           body: CoyoteBackground(
// // // //             child: SafeArea(
// // // //               child: Padding(
// // // //                 padding: const EdgeInsets.symmetric(horizontal: 24),
// // // //                 child: Column(
// // // //                   crossAxisAlignment: CrossAxisAlignment.stretch,
// // // //                   children: [
// // // //                     SizedBox(height: 20),
// // // //                     _buildHeader(),
// // // //                     const SizedBox(height: 28),
// // // //                     SegmentedControl<String>(
// // // //                       options: [
// // // //                         SegmentOption(
// // // //                           label: 'Left',
// // // //                           imageUri: _sideIndex == 0
// // // //                               ? "assets/images/left_white.svg"
// // // //                               : "assets/images/left_grey.svg",
// // // //                           isConnected: true,
// // // //                         ),
// // // //                         SegmentOption(
// // // //                           label: 'Right',
// // // //                           imageUri: _sideIndex == 1
// // // //                               ? "assets/images/right_white.svg"
// // // //                               : "assets/images/right_grey.svg",
// // // //                           isConnected: true,
// // // //                         ),
// // // //                       ],
// // // //                       selectedIndex: _sideIndex,
// // // //                       onChanged: (i) => setState(() => _sideIndex = i),
// // // //                     ),
// // // //                     const SizedBox(height: 20),

// // // //                     Expanded(
// // // //                       child:
// // // //                           _bleController.isConnected(
// // // //                             deviceSide: _sideIndex == 0
// // // //                                 ? DeviceSide.left
// // // //                                 : DeviceSide.right,
// // // //                           )
// // // //                           ? VacuumGaugeSlider(
// // // //                               minValue: 0,
// // // //                               maxValue: 20,
// // // //                               currentValue: _bleController
// // // //                                   .getCurrentPressure(
// // // //                                     _sideIndex == 0
// // // //                                         ? DeviceSide.left
// // // //                                         : DeviceSide.right,
// // // //                                   )
// // // //                                   .toDouble(),
// // // //                               targetValue: _bleController
// // // //                                   .getTargetPressure(
// // // //                                     _sideIndex == 0
// // // //                                         ? DeviceSide.left
// // // //                                         : DeviceSide.right,
// // // //                                   )
// // // //                                   .toDouble(),
// // // //                               onChanged: (value) async {
// // // //                                 final side = _sideIndex == 0
// // // //                                     ? DeviceSide.left
// // // //                                     : DeviceSide.right;
// // // //                                 _bleController.removePreset(side);
// // // //                                 _bleController.setGuage(
// // // //                                   pressure: value.toInt(),
// // // //                                   deviceSide: side,
// // // //                                 );
// // // //                               },
// // // //                             )
// // // //                           : SvgPicture.asset("assets/images/value_bar.svg"),
// // // //                     ),
// // // //                     Container(
// // // //                       height: 58,

// // // //                       decoration: BoxDecoration(
// // // //                         color: AppColors.segmentContainer,
// // // //                         borderRadius: BorderRadius.circular(12),
// // // //                         boxShadow: [
// // // //                           BoxShadow(
// // // //                             color: Colors.black.withValues(alpha: 0.2),
// // // //                             blurRadius: 4,
// // // //                             offset: const Offset(0, 1),
// // // //                           ),
// // // //                         ],
// // // //                       ),
// // // //                       child: Row(
// // // //                         // mainAxisAlignment: MainAxisAlignment.spaceBetween,
// // // //                         children: [
// // // //                           ActionWidget(
// // // //                             imageUri:
// // // //                                 _bleController.getSelectedPreset(
// // // //                                           _sideIndex == 0
// // // //                                               ? DeviceSide.left
// // // //                                               : DeviceSide.right,
// // // //                                         ) ==
// // // //                                         Presets.sit &&
// // // //                                     _bleController.isConnected(
// // // //                                       deviceSide: _sideIndex == 0
// // // //                                           ? DeviceSide.left
// // // //                                           : DeviceSide.right,
// // // //                                     )
// // // //                                 ? "assets/images/sit_white.svg"
// // // //                                 : "assets/images/sit_grey.svg",
// // // //                             label: "Sit",
// // // //                             isSelected:
// // // //                                 _bleController.getSelectedPreset(
// // // //                                       _sideIndex == 0
// // // //                                           ? DeviceSide.left
// // // //                                           : DeviceSide.right,
// // // //                                     ) ==
// // // //                                     Presets.sit &&
// // // //                                 _bleController.isConnected(
// // // //                                   deviceSide: _sideIndex == 0
// // // //                                       ? DeviceSide.left
// // // //                                       : DeviceSide.right,
// // // //                                 ),
// // // //                             onPress: () => _onPresetPressed(Presets.sit),
// // // //                           ),
// // // //                           ActionWidget(
// // // //                             imageUri:
// // // //                                 _bleController.getSelectedPreset(
// // // //                                           _sideIndex == 0
// // // //                                               ? DeviceSide.left
// // // //                                               : DeviceSide.right,
// // // //                                         ) ==
// // // //                                         Presets.walk &&
// // // //                                     _bleController.isConnected(
// // // //                                       deviceSide: _sideIndex == 0
// // // //                                           ? DeviceSide.left
// // // //                                           : DeviceSide.right,
// // // //                                     )
// // // //                                 ? "assets/images/walk_white.svg"
// // // //                                 : "assets/images/walk_grey.svg",
// // // //                             label: "Walk",
// // // //                             isSelected:
// // // //                                 _bleController.getSelectedPreset(
// // // //                                       _sideIndex == 0
// // // //                                           ? DeviceSide.left
// // // //                                           : DeviceSide.right,
// // // //                                     ) ==
// // // //                                     Presets.walk &&
// // // //                                 _bleController.isConnected(
// // // //                                   deviceSide: _sideIndex == 0
// // // //                                       ? DeviceSide.left
// // // //                                       : DeviceSide.right,
// // // //                                 ),
// // // //                             onPress: () => _onPresetPressed(Presets.walk),
// // // //                           ),
// // // //                           ActionWidget(
// // // //                             imageUri:
// // // //                                 _bleController.getSelectedPreset(
// // // //                                           _sideIndex == 0
// // // //                                               ? DeviceSide.left
// // // //                                               : DeviceSide.right,
// // // //                                         ) ==
// // // //                                         Presets.run &&
// // // //                                     _bleController.isConnected(
// // // //                                       deviceSide: _sideIndex == 0
// // // //                                           ? DeviceSide.left
// // // //                                           : DeviceSide.right,
// // // //                                     )
// // // //                                 ? "assets/images/run_white.svg"
// // // //                                 : "assets/images/run_grey.svg",
// // // //                             label: "Run",
// // // //                             isSelected:
// // // //                                 _bleController.getSelectedPreset(
// // // //                                       _sideIndex == 0
// // // //                                           ? DeviceSide.left
// // // //                                           : DeviceSide.right,
// // // //                                     ) ==
// // // //                                     Presets.run &&
// // // //                                 _bleController.isConnected(
// // // //                                   deviceSide: _sideIndex == 0
// // // //                                       ? DeviceSide.left
// // // //                                       : DeviceSide.right,
// // // //                                 ),
// // // //                             onPress: () => _onPresetPressed(Presets.run),
// // // //                           ),
// // // //                         ],
// // // //                       ),
// // // //                     ),

// // // //                     const SizedBox(height: 32),
// // // //                     SizedBox(
// // // //                       height: 76,
// // // //                       child: Row(
// // // //                         children: [
// // // //                           Expanded(
// // // //                             child: StatusCard(
// // // //                               title: 'Bluetooth',
// // // //                               isConnected: _bleController.isConnected(
// // // //                                 deviceSide: _sideIndex == 0
// // // //                                     ? DeviceSide.left
// // // //                                     : DeviceSide.right,
// // // //                               ),
// // // //                               subtitle:
// // // //                                   _bleController.isConnected(
// // // //                                     deviceSide: _sideIndex == 0
// // // //                                         ? DeviceSide.left
// // // //                                         : DeviceSide.right,
// // // //                                   )
// // // //                                   ? 'Connected'
// // // //                                   : "Disconnected",
// // // //                               imageUri: "assets/images/bluetooth.svg",
// // // //                               onTap: _onBluetoothTap,
// // // //                             ),
// // // //                           ),
// // // //                           const SizedBox(width: 8),
// // // //                           Expanded(
// // // //                             child: StatusCard(
// // // //                               title: 'Battery',
// // // //                               isConnected: _bleController.isConnected(
// // // //                                 deviceSide: _sideIndex == 0
// // // //                                     ? DeviceSide.left
// // // //                                     : DeviceSide.right,
// // // //                               ),
// // // //                               imageUri: "assets/images/battery.svg",
// // // //                               trailing:
// // // //                                   _bleController.isConnected(
// // // //                                     deviceSide: _sideIndex == 0
// // // //                                         ? DeviceSide.left
// // // //                                         : DeviceSide.right,
// // // //                                   )
// // // //                                   ? Row(
// // // //                                       mainAxisSize: MainAxisSize.min,
// // // //                                       children: [
// // // //                                         if (_bleController
// // // //                                                 .getBatteryInfo(
// // // //                                                   _sideIndex == 0
// // // //                                                       ? DeviceSide.left
// // // //                                                       : DeviceSide.right,
// // // //                                                 )
// // // //                                                 .chargingStatus ==
// // // //                                             1) ...[
// // // //                                           Icon(
// // // //                                             Icons.bolt,
// // // //                                             size: 18,
// // // //                                             color: AppColors.success,
// // // //                                           ),
// // // //                                           const SizedBox(width: 4),
// // // //                                         ],
// // // //                                         Text(
// // // //                                           '${_bleController.getBatteryInfo(_sideIndex == 0 ? DeviceSide.left : DeviceSide.right).batteryPercentage.toStringAsFixed(0)}%',
// // // //                                           style: const TextStyle(
// // // //                                             fontSize: 15,
// // // //                                             fontWeight: FontWeight.w600,
// // // //                                             color: AppColors.success,
// // // //                                           ),
// // // //                                         ),
// // // //                                       ],
// // // //                                     )
// // // //                                   : Container(),
// // // //                               onTap: _onBatteryTap,
// // // //                             ),
// // // //                           ),
// // // //                         ],
// // // //                       ),
// // // //                     ),
// // // //                     const SizedBox(height: 8),
// // // //                     PrimaryActionButton(
// // // //                       label:
// // // //                           _bleController.getPumpStatus(
// // // //                                 _sideIndex == 0
// // // //                                     ? DeviceSide.left
// // // //                                     : DeviceSide.right,
// // // //                               ) ==
// // // //                               1
// // // //                           ? 'Turn Off'
// // // //                           : 'Turn On',
// // // //                       icon: Icons.power_settings_new,
// // // //                       onPressed: _onTurnOff,
// // // //                       isOn:
// // // //                           _bleController.getPumpStatus(
// // // //                             _sideIndex == 0
// // // //                                 ? DeviceSide.left
// // // //                                 : DeviceSide.right,
// // // //                           ) ==
// // // //                           1,
// // // //                     ),
// // // //                     // const SizedBox(height: 20),
// // // //                   ],
// // // //                 ),
// // // //               ),
// // // //             ),
// // // //           ),
// // // //         );
// // // //       },
// // // //     );
// // // //   }

// // // //   Widget _buildHeader() {
// // // //     return Row(
// // // //       children: [
// // // //         SvgPicture.asset("assets/images/logo.svg"),
// // // //         // Text(
// // // //         //   'Coyote',
// // // //         //   style: TextStyle(
// // // //         //     fontSize: 24,
// // // //         //     fontWeight: FontWeight.bold,
// // // //         //     color: AppColors.textPrimary,
// // // //         //   ),
// // // //         // ),
// // // //         // const SizedBox(width: 4),
// // // //         // Icon(Icons.pets, color: AppColors.textPrimary, size: 26),
// // // //       ],
// // // //     );
// // // //   }

// // // //   void _onBluetoothTap() {
// // // //     // TODO: Open Bluetooth settings or status
// // // //   }

// // // //   void _onPresetPressed(Presets preset) {
// // // //     final side = _sideIndex == 0 ? DeviceSide.left : DeviceSide.right;
// // // //     if (!_bleController.isConnected(deviceSide: side)) {
// // // //       _showDisconnectedSnackBar(context);
// // // //       return;
// // // //     }
// // // //     _bleController.ApplyPreset(deviceSide: side, preset: preset);
// // // //   }

// // // //   void _onBatteryTap() async {
// // // //     final side = _sideIndex == 0 ? DeviceSide.left : DeviceSide.right;

// // // //     if (!_bleController.isConnected(deviceSide: side)) {
// // // //       _showDisconnectedSnackBar(context);
// // // //       return;
// // // //     }

// // // //     await _bleController.sendMessage(deviceSide: side, message: "7");
// // // //     if (!context.mounted) return;
// // // //     _showInfoDialog(context);
// // // //   }

// // // //   void _showInfoDialog(BuildContext context) {
// // // //     final side = _sideIndex == 0 ? DeviceSide.left : DeviceSide.right;
// // // //     final battery = _bleController.getBatteryInfo(side);
// // // //     showDialog(
// // // //       context: context,
// // // //       builder: (BuildContext context) {
// // // //         return AlertDialog(
// // // //           title: const Text('Battery Information'),
// // // //           content: Column(
// // // //             mainAxisSize: MainAxisSize.min,
// // // //             crossAxisAlignment: CrossAxisAlignment.start,
// // // //             children: [
// // // //               Text(
// // // //                 "Charging Status:  ${battery.chargingStatus == 1 ? "Charging" : "Not Charging"}",
// // // //               ),
// // // //               const SizedBox(height: 8),
// // // //               Text('Battery Percentage: ${battery.batteryPercentage}'),
// // // //               const SizedBox(height: 8),
// // // //               Text('Battery Voltage: ${battery.batteryVoltage}'),
// // // //             ],
// // // //           ),
// // // //           actions: [
// // // //             TextButton(
// // // //               onPressed: () => Navigator.of(context).pop(),
// // // //               child: const Text('Close'),
// // // //             ),
// // // //           ],
// // // //         );
// // // //       },
// // // //     );
// // // //   }

// // // //   void _onTurnOff() async {
// // // //     final side = _sideIndex == 0 ? DeviceSide.left : DeviceSide.right;

// // // //     if (!_bleController.isConnected(deviceSide: side)) {
// // // //       _showDisconnectedSnackBar(context);
// // // //       return;
// // // //     }

// // // //     await _bleController.sendMessage(
// // // //       message: _bleController.getPumpStatus(side) == 1 ? "2" : "1",
// // // //       deviceSide: side,
// // // //     );
// // // //   }

// // // //   void _showDisconnectedSnackBar(BuildContext context) {
// // // //     if (!context.mounted) return;
// // // //     ScaffoldMessenger.of(context).showSnackBar(
// // // //       const SnackBar(
// // // //         content: Text(
// // // //           'Device disconnected. Connect your device from the Pair screen.',
// // // //         ),
// // // //         behavior: SnackBarBehavior.floating,
// // // //       ),
// // // //     );
// // // //   }
// // // // }

// // // import 'dart:async';

// // // import 'package:coyote_app/components/action_widget.dart';
// // // import 'package:coyote_app/components/vacuum_gauge_slider.dart';
// // // import 'package:coyote_app/controller/ble_controller.dart';
// // // import 'package:flutter/material.dart';
// // // import 'package:flutter_svg/svg.dart';
// // // import 'package:get/get.dart';
// // // import '../theme/app_colors.dart';
// // // import '../components/components.dart';

// // // /// Full Coyote control screen: Left/Right, circular gauge, Sit/Walk/Run,
// // // /// Bluetooth & Battery status, and Turn Off button.
// // // class ControlScreen extends StatefulWidget {
// // //   const ControlScreen({super.key});

// // //   @override
// // //   State<ControlScreen> createState() => _ControlScreenState();
// // // }

// // // class _ControlScreenState extends State<ControlScreen> {
// // //   final BleController _bleController = Get.find<BleController>();
// // //   int _sideIndex = 0;
// // //   int _activityIndex = 0;
// // //   int _targetVacuum = 12;
// // //   double _actualVacuum = 8.4;

// // //   @override
// // //   Widget build(BuildContext context) {
// // //     return GetBuilder<BleController>(
// // //       init: _bleController,
// // //       builder: (_) {
// // //         return Scaffold(
// // //           body: CoyoteBackground(
// // //             child: SafeArea(
// // //               child: Padding(
// // //                 padding: const EdgeInsets.symmetric(horizontal: 24),
// // //                 child: Column(
// // //                   crossAxisAlignment: CrossAxisAlignment.stretch,
// // //                   children: [
// // //                     SizedBox(height: 20),
// // //                     _buildHeader(),
// // //                     const SizedBox(height: 28),
// // //                     SegmentedControl<String>(
// // //                       options: [
// // //                         SegmentOption(
// // //                           label: 'Left',
// // //                           imageUri: _sideIndex == 0
// // //                               ? "assets/images/left_white.svg"
// // //                               : "assets/images/left_grey.svg",
// // //                           isConnected: true,
// // //                         ),
// // //                         SegmentOption(
// // //                           label: 'Right',
// // //                           imageUri: _sideIndex == 1
// // //                               ? "assets/images/right_white.svg"
// // //                               : "assets/images/right_grey.svg",
// // //                           isConnected: true,
// // //                         ),
// // //                       ],
// // //                       selectedIndex: _sideIndex,
// // //                       onChanged: (i) => setState(() => _sideIndex = i),
// // //                     ),
// // //                     const SizedBox(height: 20),

// // //                     Expanded(
// // //                       child:
// // //                           _bleController.isConnected(
// // //                             deviceSide: _sideIndex == 0
// // //                                 ? DeviceSide.left
// // //                                 : DeviceSide.right,
// // //                           )
// // //                           ? Align(
// // //                               alignment: Alignment.center,
// // //                               child: VacuumGaugeSlider(
// // //                                 minValue: 0,
// // //                                 maxValue: 20,
// // //                                 currentValue: _bleController
// // //                                     .getCurrentPressure(
// // //                                       _sideIndex == 0
// // //                                           ? DeviceSide.left
// // //                                           : DeviceSide.right,
// // //                                     )
// // //                                     .toDouble(),
// // //                                 targetValue: _bleController
// // //                                     .getTargetPressure(
// // //                                       _sideIndex == 0
// // //                                           ? DeviceSide.left
// // //                                           : DeviceSide.right,
// // //                                     )
// // //                                     .toDouble(),
// // //                                 onChanged: (value) async {
// // //                                   final side = _sideIndex == 0
// // //                                       ? DeviceSide.left
// // //                                       : DeviceSide.right;
// // //                                   _bleController.removePreset(side);
// // //                                   _bleController.setGuage(
// // //                                     pressure: value.toInt(),
// // //                                     deviceSide: side,
// // //                                   );
// // //                                 },
// // //                               ),
// // //                             )
// // //                           : SvgPicture.asset("assets/images/value_bar.svg"),
// // //                     ),
// // //                     Container(
// // //                       height: 58,

// // //                       decoration: BoxDecoration(
// // //                         color: AppColors.segmentContainer,
// // //                         borderRadius: BorderRadius.circular(12),
// // //                         boxShadow: [
// // //                           BoxShadow(
// // //                             color: Colors.black.withValues(alpha: 0.2),
// // //                             blurRadius: 4,
// // //                             offset: const Offset(0, 1),
// // //                           ),
// // //                         ],
// // //                       ),
// // //                       child: Row(
// // //                         // mainAxisAlignment: MainAxisAlignment.spaceBetween,
// // //                         children: [
// // //                           ActionWidget(
// // //                             imageUri:
// // //                                 _bleController.getSelectedPreset(
// // //                                           _sideIndex == 0
// // //                                               ? DeviceSide.left
// // //                                               : DeviceSide.right,
// // //                                         ) ==
// // //                                         Presets.sit &&
// // //                                     _bleController.isConnected(
// // //                                       deviceSide: _sideIndex == 0
// // //                                           ? DeviceSide.left
// // //                                           : DeviceSide.right,
// // //                                     )
// // //                                 ? "assets/images/sit_white.svg"
// // //                                 : "assets/images/sit_grey.svg",
// // //                             label: "Sit",
// // //                             isSelected:
// // //                                 _bleController.getSelectedPreset(
// // //                                       _sideIndex == 0
// // //                                           ? DeviceSide.left
// // //                                           : DeviceSide.right,
// // //                                     ) ==
// // //                                     Presets.sit &&
// // //                                 _bleController.isConnected(
// // //                                   deviceSide: _sideIndex == 0
// // //                                       ? DeviceSide.left
// // //                                       : DeviceSide.right,
// // //                                 ),
// // //                             onPress: () => _onPresetPressed(Presets.sit),
// // //                           ),
// // //                           ActionWidget(
// // //                             imageUri:
// // //                                 _bleController.getSelectedPreset(
// // //                                           _sideIndex == 0
// // //                                               ? DeviceSide.left
// // //                                               : DeviceSide.right,
// // //                                         ) ==
// // //                                         Presets.walk &&
// // //                                     _bleController.isConnected(
// // //                                       deviceSide: _sideIndex == 0
// // //                                           ? DeviceSide.left
// // //                                           : DeviceSide.right,
// // //                                     )
// // //                                 ? "assets/images/walk_white.svg"
// // //                                 : "assets/images/walk_grey.svg",
// // //                             label: "Walk",
// // //                             isSelected:
// // //                                 _bleController.getSelectedPreset(
// // //                                       _sideIndex == 0
// // //                                           ? DeviceSide.left
// // //                                           : DeviceSide.right,
// // //                                     ) ==
// // //                                     Presets.walk &&
// // //                                 _bleController.isConnected(
// // //                                   deviceSide: _sideIndex == 0
// // //                                       ? DeviceSide.left
// // //                                       : DeviceSide.right,
// // //                                 ),
// // //                             onPress: () => _onPresetPressed(Presets.walk),
// // //                           ),
// // //                           ActionWidget(
// // //                             imageUri:
// // //                                 _bleController.getSelectedPreset(
// // //                                           _sideIndex == 0
// // //                                               ? DeviceSide.left
// // //                                               : DeviceSide.right,
// // //                                         ) ==
// // //                                         Presets.run &&
// // //                                     _bleController.isConnected(
// // //                                       deviceSide: _sideIndex == 0
// // //                                           ? DeviceSide.left
// // //                                           : DeviceSide.right,
// // //                                     )
// // //                                 ? "assets/images/run_white.svg"
// // //                                 : "assets/images/run_grey.svg",
// // //                             label: "Run",
// // //                             isSelected:
// // //                                 _bleController.getSelectedPreset(
// // //                                       _sideIndex == 0
// // //                                           ? DeviceSide.left
// // //                                           : DeviceSide.right,
// // //                                     ) ==
// // //                                     Presets.run &&
// // //                                 _bleController.isConnected(
// // //                                   deviceSide: _sideIndex == 0
// // //                                       ? DeviceSide.left
// // //                                       : DeviceSide.right,
// // //                                 ),
// // //                             onPress: () => _onPresetPressed(Presets.run),
// // //                           ),
// // //                         ],
// // //                       ),
// // //                     ),

// // //                     const SizedBox(height: 32),
// // //                     SizedBox(
// // //                       height: 76,
// // //                       child: Row(
// // //                         children: [
// // //                           Expanded(
// // //                             child: StatusCard(
// // //                               title: 'Bluetooth',
// // //                               isConnected: _bleController.isConnected(
// // //                                 deviceSide: _sideIndex == 0
// // //                                     ? DeviceSide.left
// // //                                     : DeviceSide.right,
// // //                               ),
// // //                               subtitle:
// // //                                   _bleController.isConnected(
// // //                                     deviceSide: _sideIndex == 0
// // //                                         ? DeviceSide.left
// // //                                         : DeviceSide.right,
// // //                                   )
// // //                                   ? 'Connected'
// // //                                   : "UnConnected",
// // //                               imageUri: "assets/images/bluetooth.svg",
// // //                               onTap: _onBluetoothTap,
// // //                             ),
// // //                           ),
// // //                           const SizedBox(width: 8),
// // //                           Expanded(
// // //                             child: StatusCard(
// // //                               title: 'Battery',
// // //                               isConnected: _bleController.isConnected(
// // //                                 deviceSide: _sideIndex == 0
// // //                                     ? DeviceSide.left
// // //                                     : DeviceSide.right,
// // //                               ),
// // //                               imageUri: "assets/images/battery.svg",
// // //                               trailing:
// // //                                   _bleController.isConnected(
// // //                                     deviceSide: _sideIndex == 0
// // //                                         ? DeviceSide.left
// // //                                         : DeviceSide.right,
// // //                                   )
// // //                                   ? Row(
// // //                                       mainAxisSize: MainAxisSize.min,
// // //                                       children: [
// // //                                         if (_bleController
// // //                                                 .getBatteryInfo(
// // //                                                   _sideIndex == 0
// // //                                                       ? DeviceSide.left
// // //                                                       : DeviceSide.right,
// // //                                                 )
// // //                                                 .chargingStatus ==
// // //                                             1) ...[
// // //                                           Icon(
// // //                                             Icons.bolt,
// // //                                             size: 18,
// // //                                             color: AppColors.success,
// // //                                           ),
// // //                                           const SizedBox(width: 4),
// // //                                         ],
// // //                                         Text(
// // //                                           '${_bleController.getBatteryInfo(_sideIndex == 0 ? DeviceSide.left : DeviceSide.right).batteryPercentage.toStringAsFixed(0)}%',
// // //                                           style: const TextStyle(
// // //                                             fontSize: 15,
// // //                                             fontWeight: FontWeight.w600,
// // //                                             color: AppColors.success,
// // //                                           ),
// // //                                         ),
// // //                                       ],
// // //                                     )
// // //                                   : Container(),
// // //                               onTap: _onBatteryTap,
// // //                             ),
// // //                           ),
// // //                         ],
// // //                       ),
// // //                     ),
// // //                     const SizedBox(height: 8),
// // //                     PrimaryActionButton(
// // //                       label:
// // //                           _bleController.getPumpStatus(
// // //                                 _sideIndex == 0
// // //                                     ? DeviceSide.left
// // //                                     : DeviceSide.right,
// // //                               ) ==
// // //                               1
// // //                           ? 'Turn Off'
// // //                           : 'Turn On',
// // //                       icon: Icons.power_settings_new,
// // //                       onPressed: _onTurnOff,
// // //                       isOn:
// // //                           _bleController.getPumpStatus(
// // //                             _sideIndex == 0
// // //                                 ? DeviceSide.left
// // //                                 : DeviceSide.right,
// // //                           ) ==
// // //                           1,
// // //                     ),
// // //                     // const SizedBox(height: 20),
// // //                   ],
// // //                 ),
// // //               ),
// // //             ),
// // //           ),
// // //         );
// // //       },
// // //     );
// // //   }

// // //   Widget _buildHeader() {
// // //     return Row(
// // //       children: [
// // //         SvgPicture.asset("assets/images/logo.svg"),
// // //         // Text(
// // //         //   'Coyote',
// // //         //   style: TextStyle(
// // //         //     fontSize: 24,
// // //         //     fontWeight: FontWeight.bold,
// // //         //     color: AppColors.textPrimary,
// // //         //   ),
// // //         // ),
// // //         // const SizedBox(width: 4),
// // //         // Icon(Icons.pets, color: AppColors.textPrimary, size: 26),
// // //       ],
// // //     );
// // //   }

// // //   void _onBluetoothTap() {
// // //     // TODO: Open Bluetooth settings or status
// // //   }

// // //   void _onPresetPressed(Presets preset) {
// // //     final side = _sideIndex == 0 ? DeviceSide.left : DeviceSide.right;
// // //     if (!_bleController.isConnected(deviceSide: side)) {
// // //       _showDisconnectedSnackBar(context);
// // //       return;
// // //     }
// // //     _bleController.ApplyPreset(deviceSide: side, preset: preset);
// // //   }

// // //   void _onBatteryTap() async {
// // //     final side = _sideIndex == 0 ? DeviceSide.left : DeviceSide.right;

// // //     if (!_bleController.isConnected(deviceSide: side)) {
// // //       _showDisconnectedSnackBar(context);
// // //       return;
// // //     }

// // //     await _bleController.sendMessage(deviceSide: side, message: "7");
// // //     if (!context.mounted) return;
// // //     _showInfoDialog(context);
// // //   }

// // //   void _showInfoDialog(BuildContext context) {
// // //     final side = _sideIndex == 0 ? DeviceSide.left : DeviceSide.right;
// // //     final battery = _bleController.getBatteryInfo(side);
// // //     showDialog(
// // //       context: context,
// // //       builder: (BuildContext context) {
// // //         return AlertDialog(
// // //           title: const Text('Battery Information'),
// // //           content: Column(
// // //             mainAxisSize: MainAxisSize.min,
// // //             crossAxisAlignment: CrossAxisAlignment.start,
// // //             children: [
// // //               Text(
// // //                 "Charging Status:  ${battery.chargingStatus == 1 ? "Charging" : "Not Charging"}",
// // //               ),
// // //               const SizedBox(height: 8),
// // //               Text('Battery Percentage: ${battery.batteryPercentage}'),
// // //               const SizedBox(height: 8),
// // //               Text('Battery Voltage: ${battery.batteryVoltage}'),
// // //             ],
// // //           ),
// // //           actions: [
// // //             TextButton(
// // //               onPressed: () => Navigator.of(context).pop(),
// // //               child: const Text('Close'),
// // //             ),
// // //           ],
// // //         );
// // //       },
// // //     );
// // //   }

// // //   void _onTurnOff() async {
// // //     final side = _sideIndex == 0 ? DeviceSide.left : DeviceSide.right;

// // //     if (!_bleController.isConnected(deviceSide: side)) {
// // //       _showDisconnectedSnackBar(context);
// // //       return;
// // //     }

// // //     await _bleController.sendMessage(
// // //       message: _bleController.getPumpStatus(side) == 1 ? "2" : "1",
// // //       deviceSide: side,
// // //     );
// // //   }

// // //   void _showDisconnectedSnackBar(BuildContext context) {
// // //     if (!context.mounted) return;
// // //     final messenger = ScaffoldMessenger.of(context);
// // //     messenger.clearSnackBars();
// // //     messenger.showSnackBar(
// // //       const SnackBar(
// // //         content: Text(
// // //           'Device disconnected. Connect your device from the Pair screen.',
// // //         ),
// // //         behavior: SnackBarBehavior.floating,
// // //       ),
// // //     );
// // //   }
// // // }

// // // import 'dart:async';

// // // import 'package:coyote_app/components/action_widget.dart';
// // // import 'package:coyote_app/components/vacuum_gauge_slider.dart';
// // // import 'package:coyote_app/controller/ble_controller.dart';
// // // import 'package:flutter/material.dart';
// // // import 'package:flutter_svg/svg.dart';
// // // import 'package:get/get.dart';
// // // import '../theme/app_colors.dart';
// // // import '../components/components.dart';

// // // /// Full Coyote control screen: Left/Right, circular gauge, Sit/Walk/Run,
// // // /// Bluetooth & Battery status, and Turn Off button.
// // // class ControlScreen extends StatefulWidget {
// // //   const ControlScreen({super.key});

// // //   @override
// // //   State<ControlScreen> createState() => _ControlScreenState();
// // // }

// // // class _ControlScreenState extends State<ControlScreen> {
// // //   final BleController _bleController = Get.find<BleController>();
// // //   int _sideIndex = 0;
// // //   int _activityIndex = 0;
// // //   int _targetVacuum = 12;
// // //   double _actualVacuum = 8.4;

// // //   @override
// // //   void initState() {
// // //     super.initState();
// // //     // Auto-switch to a side the moment it becomes the only connected side.
// // //     _bleController.onSingleSideConnected = (side) {
// // //       if (mounted) setState(() => _sideIndex = side == DeviceSide.left ? 0 : 1);
// // //     };
// // //   }

// // //   @override
// // //   void dispose() {
// // //     _bleController.onSingleSideConnected = null;
// // //     super.dispose();
// // //   }

// // //   @override
// // //   Widget build(BuildContext context) {
// // //     return GetBuilder<BleController>(
// // //       init: _bleController,
// // //       builder: (_) {
// // //         return Scaffold(
// // //           body: CoyoteBackground(
// // //             child: SafeArea(
// // //               child: Padding(
// // //                 padding: const EdgeInsets.symmetric(horizontal: 24),
// // //                 child: Column(
// // //                   crossAxisAlignment: CrossAxisAlignment.stretch,
// // //                   children: [
// // //                     SizedBox(height: 20),
// // //                     _buildHeader(),
// // //                     const SizedBox(height: 28),
// // //                     SegmentedControl<String>(
// // //                       options: [
// // //                         SegmentOption(
// // //                           label: 'Left',
// // //                           imageUri: _sideIndex == 0
// // //                               ? "assets/images/left_white.svg"
// // //                               : "assets/images/left_grey.svg",
// // //                           isConnected: true,
// // //                         ),
// // //                         SegmentOption(
// // //                           label: 'Right',
// // //                           imageUri: _sideIndex == 1
// // //                               ? "assets/images/right_white.svg"
// // //                               : "assets/images/right_grey.svg",
// // //                           isConnected: true,
// // //                         ),
// // //                       ],
// // //                       selectedIndex: _sideIndex,
// // //                       onChanged: (i) => setState(() => _sideIndex = i),
// // //                     ),
// // //                     const SizedBox(height: 20),

// // //                     Expanded(
// // //                       child:
// // //                           _bleController.isConnected(
// // //                             deviceSide: _sideIndex == 0
// // //                                 ? DeviceSide.left
// // //                                 : DeviceSide.right,
// // //                           )
// // //                           ? VacuumGaugeSlider(
// // //                               minValue: 0,
// // //                               maxValue: 20,
// // //                               currentValue: _bleController
// // //                                   .getCurrentPressure(
// // //                                     _sideIndex == 0
// // //                                         ? DeviceSide.left
// // //                                         : DeviceSide.right,
// // //                                   )
// // //                                   .toDouble(),
// // //                               targetValue: _bleController
// // //                                   .getTargetPressure(
// // //                                     _sideIndex == 0
// // //                                         ? DeviceSide.left
// // //                                         : DeviceSide.right,
// // //                                   )
// // //                                   .toDouble(),
// // //                               onChanged: (value) async {
// // //                                 final side = _sideIndex == 0
// // //                                     ? DeviceSide.left
// // //                                     : DeviceSide.right;
// // //                                 _bleController.removePreset(side);
// // //                                 _bleController.setGuage(
// // //                                   pressure: value.toInt(),
// // //                                   deviceSide: side,
// // //                                 );
// // //                               },
// // //                             )
// // //                           : SvgPicture.asset("assets/images/value_bar.svg"),
// // //                     ),
// // //                     Container(
// // //                       height: 58,

// // //                       decoration: BoxDecoration(
// // //                         color: AppColors.segmentContainer,
// // //                         borderRadius: BorderRadius.circular(12),
// // //                         boxShadow: [
// // //                           BoxShadow(
// // //                             color: Colors.black.withValues(alpha: 0.2),
// // //                             blurRadius: 4,
// // //                             offset: const Offset(0, 1),
// // //                           ),
// // //                         ],
// // //                       ),
// // //                       child: Row(
// // //                         // mainAxisAlignment: MainAxisAlignment.spaceBetween,
// // //                         children: [
// // //                           ActionWidget(
// // //                             imageUri:
// // //                                 _bleController.getSelectedPreset(
// // //                                           _sideIndex == 0
// // //                                               ? DeviceSide.left
// // //                                               : DeviceSide.right,
// // //                                         ) ==
// // //                                         Presets.sit &&
// // //                                     _bleController.isConnected(
// // //                                       deviceSide: _sideIndex == 0
// // //                                           ? DeviceSide.left
// // //                                           : DeviceSide.right,
// // //                                     )
// // //                                 ? "assets/images/sit_white.svg"
// // //                                 : "assets/images/sit_grey.svg",
// // //                             label: "Sit",
// // //                             isSelected:
// // //                                 _bleController.getSelectedPreset(
// // //                                       _sideIndex == 0
// // //                                           ? DeviceSide.left
// // //                                           : DeviceSide.right,
// // //                                     ) ==
// // //                                     Presets.sit &&
// // //                                 _bleController.isConnected(
// // //                                   deviceSide: _sideIndex == 0
// // //                                       ? DeviceSide.left
// // //                                       : DeviceSide.right,
// // //                                 ),
// // //                             onPress: () => _onPresetPressed(Presets.sit),
// // //                           ),
// // //                           ActionWidget(
// // //                             imageUri:
// // //                                 _bleController.getSelectedPreset(
// // //                                           _sideIndex == 0
// // //                                               ? DeviceSide.left
// // //                                               : DeviceSide.right,
// // //                                         ) ==
// // //                                         Presets.walk &&
// // //                                     _bleController.isConnected(
// // //                                       deviceSide: _sideIndex == 0
// // //                                           ? DeviceSide.left
// // //                                           : DeviceSide.right,
// // //                                     )
// // //                                 ? "assets/images/walk_white.svg"
// // //                                 : "assets/images/walk_grey.svg",
// // //                             label: "Walk",
// // //                             isSelected:
// // //                                 _bleController.getSelectedPreset(
// // //                                       _sideIndex == 0
// // //                                           ? DeviceSide.left
// // //                                           : DeviceSide.right,
// // //                                     ) ==
// // //                                     Presets.walk &&
// // //                                 _bleController.isConnected(
// // //                                   deviceSide: _sideIndex == 0
// // //                                       ? DeviceSide.left
// // //                                       : DeviceSide.right,
// // //                                 ),
// // //                             onPress: () => _onPresetPressed(Presets.walk),
// // //                           ),
// // //                           ActionWidget(
// // //                             imageUri:
// // //                                 _bleController.getSelectedPreset(
// // //                                           _sideIndex == 0
// // //                                               ? DeviceSide.left
// // //                                               : DeviceSide.right,
// // //                                         ) ==
// // //                                         Presets.run &&
// // //                                     _bleController.isConnected(
// // //                                       deviceSide: _sideIndex == 0
// // //                                           ? DeviceSide.left
// // //                                           : DeviceSide.right,
// // //                                     )
// // //                                 ? "assets/images/run_white.svg"
// // //                                 : "assets/images/run_grey.svg",
// // //                             label: "Run",
// // //                             isSelected:
// // //                                 _bleController.getSelectedPreset(
// // //                                       _sideIndex == 0
// // //                                           ? DeviceSide.left
// // //                                           : DeviceSide.right,
// // //                                     ) ==
// // //                                     Presets.run &&
// // //                                 _bleController.isConnected(
// // //                                   deviceSide: _sideIndex == 0
// // //                                       ? DeviceSide.left
// // //                                       : DeviceSide.right,
// // //                                 ),
// // //                             onPress: () => _onPresetPressed(Presets.run),
// // //                           ),
// // //                         ],
// // //                       ),
// // //                     ),

// // //                     const SizedBox(height: 32),
// // //                     SizedBox(
// // //                       height: 76,
// // //                       child: Row(
// // //                         children: [
// // //                           Expanded(
// // //                             child: StatusCard(
// // //                               title: 'Bluetooth',
// // //                               isConnected: _bleController.isConnected(
// // //                                 deviceSide: _sideIndex == 0
// // //                                     ? DeviceSide.left
// // //                                     : DeviceSide.right,
// // //                               ),
// // //                               subtitle:
// // //                                   _bleController.isConnected(
// // //                                     deviceSide: _sideIndex == 0
// // //                                         ? DeviceSide.left
// // //                                         : DeviceSide.right,
// // //                                   )
// // //                                   ? 'Connected'
// // //                                   : "Disconnected",
// // //                               imageUri: "assets/images/bluetooth.svg",
// // //                               onTap: _onBluetoothTap,
// // //                             ),
// // //                           ),
// // //                           const SizedBox(width: 8),
// // //                           Expanded(
// // //                             child: StatusCard(
// // //                               title: 'Battery',
// // //                               isConnected: _bleController.isConnected(
// // //                                 deviceSide: _sideIndex == 0
// // //                                     ? DeviceSide.left
// // //                                     : DeviceSide.right,
// // //                               ),
// // //                               imageUri: "assets/images/battery.svg",
// // //                               trailing:
// // //                                   _bleController.isConnected(
// // //                                     deviceSide: _sideIndex == 0
// // //                                         ? DeviceSide.left
// // //                                         : DeviceSide.right,
// // //                                   )
// // //                                   ? Row(
// // //                                       mainAxisSize: MainAxisSize.min,
// // //                                       children: [
// // //                                         if (_bleController
// // //                                                 .getBatteryInfo(
// // //                                                   _sideIndex == 0
// // //                                                       ? DeviceSide.left
// // //                                                       : DeviceSide.right,
// // //                                                 )
// // //                                                 .chargingStatus ==
// // //                                             1) ...[
// // //                                           Icon(
// // //                                             Icons.bolt,
// // //                                             size: 18,
// // //                                             color: AppColors.success,
// // //                                           ),
// // //                                           const SizedBox(width: 4),
// // //                                         ],
// // //                                         Text(
// // //                                           '${_bleController.getBatteryInfo(_sideIndex == 0 ? DeviceSide.left : DeviceSide.right).batteryPercentage.toStringAsFixed(0)}%',
// // //                                           style: const TextStyle(
// // //                                             fontSize: 15,
// // //                                             fontWeight: FontWeight.w600,
// // //                                             color: AppColors.success,
// // //                                           ),
// // //                                         ),
// // //                                       ],
// // //                                     )
// // //                                   : Container(),
// // //                               onTap: _onBatteryTap,
// // //                             ),
// // //                           ),
// // //                         ],
// // //                       ),
// // //                     ),
// // //                     const SizedBox(height: 8),
// // //                     PrimaryActionButton(
// // //                       label:
// // //                           _bleController.getPumpStatus(
// // //                                 _sideIndex == 0
// // //                                     ? DeviceSide.left
// // //                                     : DeviceSide.right,
// // //                               ) ==
// // //                               1
// // //                           ? 'Turn Off'
// // //                           : 'Turn On',
// // //                       icon: Icons.power_settings_new,
// // //                       onPressed: _onTurnOff,
// // //                       isOn:
// // //                           _bleController.getPumpStatus(
// // //                             _sideIndex == 0
// // //                                 ? DeviceSide.left
// // //                                 : DeviceSide.right,
// // //                           ) ==
// // //                           1,
// // //                     ),
// // //                     // const SizedBox(height: 20),
// // //                   ],
// // //                 ),
// // //               ),
// // //             ),
// // //           ),
// // //         );
// // //       },
// // //     );
// // //   }

// // //   Widget _buildHeader() {
// // //     return Row(
// // //       children: [
// // //         SvgPicture.asset("assets/images/logo.svg"),
// // //         // Text(
// // //         //   'Coyote',
// // //         //   style: TextStyle(
// // //         //     fontSize: 24,
// // //         //     fontWeight: FontWeight.bold,
// // //         //     color: AppColors.textPrimary,
// // //         //   ),
// // //         // ),
// // //         // const SizedBox(width: 4),
// // //         // Icon(Icons.pets, color: AppColors.textPrimary, size: 26),
// // //       ],
// // //     );
// // //   }

// // //   void _onBluetoothTap() {
// // //     // TODO: Open Bluetooth settings or status
// // //   }

// // //   void _onPresetPressed(Presets preset) {
// // //     final side = _sideIndex == 0 ? DeviceSide.left : DeviceSide.right;
// // //     if (!_bleController.isConnected(deviceSide: side)) {
// // //       _showDisconnectedSnackBar(context);
// // //       return;
// // //     }
// // //     _bleController.ApplyPreset(deviceSide: side, preset: preset);
// // //   }

// // //   void _onBatteryTap() async {
// // //     final side = _sideIndex == 0 ? DeviceSide.left : DeviceSide.right;

// // //     if (!_bleController.isConnected(deviceSide: side)) {
// // //       _showDisconnectedSnackBar(context);
// // //       return;
// // //     }

// // //     await _bleController.sendMessage(deviceSide: side, message: "7");
// // //     if (!context.mounted) return;
// // //     _showInfoDialog(context);
// // //   }

// // //   void _showInfoDialog(BuildContext context) {
// // //     final side = _sideIndex == 0 ? DeviceSide.left : DeviceSide.right;
// // //     final battery = _bleController.getBatteryInfo(side);
// // //     showDialog(
// // //       context: context,
// // //       builder: (BuildContext context) {
// // //         return AlertDialog(
// // //           title: const Text('Battery Information'),
// // //           content: Column(
// // //             mainAxisSize: MainAxisSize.min,
// // //             crossAxisAlignment: CrossAxisAlignment.start,
// // //             children: [
// // //               Text(
// // //                 "Charging Status:  ${battery.chargingStatus == 1 ? "Charging" : "Not Charging"}",
// // //               ),
// // //               const SizedBox(height: 8),
// // //               Text('Battery Percentage: ${battery.batteryPercentage}'),
// // //               const SizedBox(height: 8),
// // //               Text('Battery Voltage: ${battery.batteryVoltage}'),
// // //             ],
// // //           ),
// // //           actions: [
// // //             TextButton(
// // //               onPressed: () => Navigator.of(context).pop(),
// // //               child: const Text('Close'),
// // //             ),
// // //           ],
// // //         );
// // //       },
// // //     );
// // //   }

// // //   void _onTurnOff() async {
// // //     final side = _sideIndex == 0 ? DeviceSide.left : DeviceSide.right;

// // //     if (!_bleController.isConnected(deviceSide: side)) {
// // //       _showDisconnectedSnackBar(context);
// // //       return;
// // //     }

// // //     await _bleController.sendMessage(
// // //       message: _bleController.getPumpStatus(side) == 1 ? "2" : "1",
// // //       deviceSide: side,
// // //     );
// // //   }

// // //   void _showDisconnectedSnackBar(BuildContext context) {
// // //     if (!context.mounted) return;
// // //     ScaffoldMessenger.of(context).showSnackBar(
// // //       const SnackBar(
// // //         content: Text(
// // //           'Device disconnected. Connect your device from the Pair screen.',
// // //         ),
// // //         behavior: SnackBarBehavior.floating,
// // //       ),
// // //     );
// // //   }
// // // }

// // import 'dart:async';

// // import 'package:coyote_app/components/action_widget.dart';
// // import 'package:coyote_app/components/vacuum_gauge_slider.dart';
// // import 'package:coyote_app/controller/ble_controller.dart';
// // import 'package:flutter/material.dart';
// // import 'package:flutter_svg/svg.dart';
// // import 'package:get/get.dart';
// // import '../theme/app_colors.dart';
// // import '../components/components.dart';

// // /// Full Coyote control screen: Left/Right, circular gauge, Sit/Walk/Run,
// // /// Bluetooth & Battery status, and Turn Off button.
// // class ControlScreen extends StatefulWidget {
// //   const ControlScreen({super.key});

// //   @override
// //   State<ControlScreen> createState() => _ControlScreenState();
// // }

// // class _ControlScreenState extends State<ControlScreen> {
// //   final BleController _bleController = Get.find<BleController>();
// //   int _sideIndex = 0;
// //   int _activityIndex = 0;
// //   int _targetVacuum = 12;
// //   double _actualVacuum = 8.4;

// //   @override
// //   Widget build(BuildContext context) {
// //     return GetBuilder<BleController>(
// //       init: _bleController,
// //       builder: (_) {
// //         return Scaffold(
// //           body: CoyoteBackground(
// //             child: SafeArea(
// //               child: Padding(
// //                 padding: const EdgeInsets.symmetric(horizontal: 24),
// //                 child: Column(
// //                   crossAxisAlignment: CrossAxisAlignment.stretch,
// //                   children: [
// //                     SizedBox(height: 20),
// //                     _buildHeader(),
// //                     const SizedBox(height: 28),
// //                     SegmentedControl<String>(
// //                       options: [
// //                         SegmentOption(
// //                           label: 'Left',
// //                           imageUri: _sideIndex == 0
// //                               ? "assets/images/left_white.svg"
// //                               : "assets/images/left_grey.svg",
// //                           isConnected: true,
// //                         ),
// //                         SegmentOption(
// //                           label: 'Right',
// //                           imageUri: _sideIndex == 1
// //                               ? "assets/images/right_white.svg"
// //                               : "assets/images/right_grey.svg",
// //                           isConnected: true,
// //                         ),
// //                       ],
// //                       selectedIndex: _sideIndex,
// //                       onChanged: (i) => setState(() => _sideIndex = i),
// //                     ),
// //                     const SizedBox(height: 20),

// //                     Expanded(
// //                       child:
// //                           _bleController.isConnected(
// //                             deviceSide: _sideIndex == 0
// //                                 ? DeviceSide.left
// //                                 : DeviceSide.right,
// //                           )
// //                           ? Align(
// //                               alignment: Alignment.center,
// //                               child: VacuumGaugeSlider(
// //                                 minValue: 0,
// //                                 maxValue: 20,
// //                                 currentValue: _bleController
// //                                     .getCurrentPressure(
// //                                       _sideIndex == 0
// //                                           ? DeviceSide.left
// //                                           : DeviceSide.right,
// //                                     )
// //                                     .toDouble(),
// //                                 targetValue: _bleController
// //                                     .getTargetPressure(
// //                                       _sideIndex == 0
// //                                           ? DeviceSide.left
// //                                           : DeviceSide.right,
// //                                     )
// //                                     .toDouble(),
// //                                 onChanged: (value) async {
// //                                   final side = _sideIndex == 0
// //                                       ? DeviceSide.left
// //                                       : DeviceSide.right;
// //                                   _bleController.removePreset(side);
// //                                   _bleController.setGuage(
// //                                     pressure: value.toInt(),
// //                                     deviceSide: side,
// //                                   );
// //                                 },
// //                               ),
// //                             )
// //                           : SvgPicture.asset("assets/images/value_bar.svg"),
// //                     ),
// //                     Container(
// //                       height: 58,

// //                       decoration: BoxDecoration(
// //                         color: AppColors.segmentContainer,
// //                         borderRadius: BorderRadius.circular(12),
// //                         boxShadow: [
// //                           BoxShadow(
// //                             color: Colors.black.withValues(alpha: 0.2),
// //                             blurRadius: 4,
// //                             offset: const Offset(0, 1),
// //                           ),
// //                         ],
// //                       ),
// //                       child: Row(
// //                         // mainAxisAlignment: MainAxisAlignment.spaceBetween,
// //                         children: [
// //                           ActionWidget(
// //                             imageUri:
// //                                 _bleController.getSelectedPreset(
// //                                           _sideIndex == 0
// //                                               ? DeviceSide.left
// //                                               : DeviceSide.right,
// //                                         ) ==
// //                                         Presets.sit &&
// //                                     _bleController.isConnected(
// //                                       deviceSide: _sideIndex == 0
// //                                           ? DeviceSide.left
// //                                           : DeviceSide.right,
// //                                     )
// //                                 ? "assets/images/sit_white.svg"
// //                                 : "assets/images/sit_grey.svg",
// //                             label: "Sit",
// //                             isSelected:
// //                                 _bleController.getSelectedPreset(
// //                                       _sideIndex == 0
// //                                           ? DeviceSide.left
// //                                           : DeviceSide.right,
// //                                     ) ==
// //                                     Presets.sit &&
// //                                 _bleController.isConnected(
// //                                   deviceSide: _sideIndex == 0
// //                                       ? DeviceSide.left
// //                                       : DeviceSide.right,
// //                                 ),
// //                             onPress: () => _onPresetPressed(Presets.sit),
// //                           ),
// //                           ActionWidget(
// //                             imageUri:
// //                                 _bleController.getSelectedPreset(
// //                                           _sideIndex == 0
// //                                               ? DeviceSide.left
// //                                               : DeviceSide.right,
// //                                         ) ==
// //                                         Presets.walk &&
// //                                     _bleController.isConnected(
// //                                       deviceSide: _sideIndex == 0
// //                                           ? DeviceSide.left
// //                                           : DeviceSide.right,
// //                                     )
// //                                 ? "assets/images/walk_white.svg"
// //                                 : "assets/images/walk_grey.svg",
// //                             label: "Walk",
// //                             isSelected:
// //                                 _bleController.getSelectedPreset(
// //                                       _sideIndex == 0
// //                                           ? DeviceSide.left
// //                                           : DeviceSide.right,
// //                                     ) ==
// //                                     Presets.walk &&
// //                                 _bleController.isConnected(
// //                                   deviceSide: _sideIndex == 0
// //                                       ? DeviceSide.left
// //                                       : DeviceSide.right,
// //                                 ),
// //                             onPress: () => _onPresetPressed(Presets.walk),
// //                           ),
// //                           ActionWidget(
// //                             imageUri:
// //                                 _bleController.getSelectedPreset(
// //                                           _sideIndex == 0
// //                                               ? DeviceSide.left
// //                                               : DeviceSide.right,
// //                                         ) ==
// //                                         Presets.run &&
// //                                     _bleController.isConnected(
// //                                       deviceSide: _sideIndex == 0
// //                                           ? DeviceSide.left
// //                                           : DeviceSide.right,
// //                                     )
// //                                 ? "assets/images/run_white.svg"
// //                                 : "assets/images/run_grey.svg",
// //                             label: "Run",
// //                             isSelected:
// //                                 _bleController.getSelectedPreset(
// //                                       _sideIndex == 0
// //                                           ? DeviceSide.left
// //                                           : DeviceSide.right,
// //                                     ) ==
// //                                     Presets.run &&
// //                                 _bleController.isConnected(
// //                                   deviceSide: _sideIndex == 0
// //                                       ? DeviceSide.left
// //                                       : DeviceSide.right,
// //                                 ),
// //                             onPress: () => _onPresetPressed(Presets.run),
// //                           ),
// //                         ],
// //                       ),
// //                     ),

// //                     const SizedBox(height: 32),
// //                     SizedBox(
// //                       height: 76,
// //                       child: Row(
// //                         children: [
// //                           Expanded(
// //                             child: StatusCard(
// //                               title: 'Bluetooth',
// //                               isConnected: _bleController.isConnected(
// //                                 deviceSide: _sideIndex == 0
// //                                     ? DeviceSide.left
// //                                     : DeviceSide.right,
// //                               ),
// //                               subtitle:
// //                                   _bleController.isConnected(
// //                                     deviceSide: _sideIndex == 0
// //                                         ? DeviceSide.left
// //                                         : DeviceSide.right,
// //                                   )
// //                                   ? 'Connected'
// //                                   : "UnConnected",
// //                               imageUri: "assets/images/bluetooth.svg",
// //                               onTap: _onBluetoothTap,
// //                             ),
// //                           ),
// //                           const SizedBox(width: 8),
// //                           Expanded(
// //                             child: StatusCard(
// //                               title: 'Battery',
// //                               isConnected: _bleController.isConnected(
// //                                 deviceSide: _sideIndex == 0
// //                                     ? DeviceSide.left
// //                                     : DeviceSide.right,
// //                               ),
// //                               imageUri: "assets/images/battery.svg",
// //                               trailing:
// //                                   _bleController.isConnected(
// //                                     deviceSide: _sideIndex == 0
// //                                         ? DeviceSide.left
// //                                         : DeviceSide.right,
// //                                   )
// //                                   ? Row(
// //                                       mainAxisSize: MainAxisSize.min,
// //                                       children: [
// //                                         if (_bleController
// //                                                 .getBatteryInfo(
// //                                                   _sideIndex == 0
// //                                                       ? DeviceSide.left
// //                                                       : DeviceSide.right,
// //                                                 )
// //                                                 .chargingStatus ==
// //                                             1) ...[
// //                                           Icon(
// //                                             Icons.bolt,
// //                                             size: 18,
// //                                             color: AppColors.success,
// //                                           ),
// //                                           const SizedBox(width: 4),
// //                                         ],
// //                                         Text(
// //                                           '${_bleController.getBatteryInfo(_sideIndex == 0 ? DeviceSide.left : DeviceSide.right).batteryPercentage.toStringAsFixed(0)}%',
// //                                           style: const TextStyle(
// //                                             fontSize: 15,
// //                                             fontWeight: FontWeight.w600,
// //                                             color: AppColors.success,
// //                                           ),
// //                                         ),
// //                                       ],
// //                                     )
// //                                   : Container(),
// //                               onTap: _onBatteryTap,
// //                             ),
// //                           ),
// //                         ],
// //                       ),
// //                     ),
// //                     const SizedBox(height: 8),
// //                     PrimaryActionButton(
// //                       label:
// //                           _bleController.getPumpStatus(
// //                                 _sideIndex == 0
// //                                     ? DeviceSide.left
// //                                     : DeviceSide.right,
// //                               ) ==
// //                               1
// //                           ? 'Turn Off'
// //                           : 'Turn On',
// //                       icon: Icons.power_settings_new,
// //                       onPressed: _onTurnOff,
// //                       isOn:
// //                           _bleController.getPumpStatus(
// //                             _sideIndex == 0
// //                                 ? DeviceSide.left
// //                                 : DeviceSide.right,
// //                           ) ==
// //                           1,
// //                     ),
// //                     // const SizedBox(height: 20),
// //                   ],
// //                 ),
// //               ),
// //             ),
// //           ),
// //         );
// //       },
// //     );
// //   }

// //   Widget _buildHeader() {
// //     return Row(
// //       children: [
// //         SvgPicture.asset("assets/images/logo.svg"),
// //         // Text(
// //         //   'Coyote',
// //         //   style: TextStyle(
// //         //     fontSize: 24,
// //         //     fontWeight: FontWeight.bold,
// //         //     color: AppColors.textPrimary,
// //         //   ),
// //         // ),
// //         // const SizedBox(width: 4),
// //         // Icon(Icons.pets, color: AppColors.textPrimary, size: 26),
// //       ],
// //     );
// //   }

// //   void _onBluetoothTap() {
// //     // TODO: Open Bluetooth settings or status
// //   }

// //   void _onPresetPressed(Presets preset) {
// //     final side = _sideIndex == 0 ? DeviceSide.left : DeviceSide.right;
// //     if (!_bleController.isConnected(deviceSide: side)) {
// //       _showDisconnectedSnackBar(context);
// //       return;
// //     }
// //     _bleController.ApplyPreset(deviceSide: side, preset: preset);
// //   }

// //   void _onBatteryTap() async {
// //     final side = _sideIndex == 0 ? DeviceSide.left : DeviceSide.right;

// //     if (!_bleController.isConnected(deviceSide: side)) {
// //       _showDisconnectedSnackBar(context);
// //       return;
// //     }

// //     await _bleController.sendMessage(deviceSide: side, message: "7");
// //     if (!context.mounted) return;
// //     _showInfoDialog(context);
// //   }

// //   void _showInfoDialog(BuildContext context) {
// //     final side = _sideIndex == 0 ? DeviceSide.left : DeviceSide.right;
// //     final battery = _bleController.getBatteryInfo(side);
// //     showDialog(
// //       context: context,
// //       builder: (BuildContext context) {
// //         return AlertDialog(
// //           title: const Text('Battery Information'),
// //           content: Column(
// //             mainAxisSize: MainAxisSize.min,
// //             crossAxisAlignment: CrossAxisAlignment.start,
// //             children: [
// //               Text(
// //                 "Charging Status:  ${battery.chargingStatus == 1 ? "Charging" : "Not Charging"}",
// //               ),
// //               const SizedBox(height: 8),
// //               Text('Battery Percentage: ${battery.batteryPercentage}'),
// //               const SizedBox(height: 8),
// //               Text('Battery Voltage: ${battery.batteryVoltage}'),
// //             ],
// //           ),
// //           actions: [
// //             TextButton(
// //               onPressed: () => Navigator.of(context).pop(),
// //               child: const Text('Close'),
// //             ),
// //           ],
// //         );
// //       },
// //     );
// //   }

// //   void _onTurnOff() async {
// //     final side = _sideIndex == 0 ? DeviceSide.left : DeviceSide.right;

// //     if (!_bleController.isConnected(deviceSide: side)) {
// //       _showDisconnectedSnackBar(context);
// //       return;
// //     }

// //     await _bleController.sendMessage(
// //       message: _bleController.getPumpStatus(side) == 1 ? "2" : "1",
// //       deviceSide: side,
// //     );
// //   }

// //   void _showDisconnectedSnackBar(BuildContext context) {
// //     if (!context.mounted) return;
// //     final messenger = ScaffoldMessenger.of(context);
// //     messenger.clearSnackBars();
// //     messenger.showSnackBar(
// //       const SnackBar(
// //         content: Text(
// //           'Device disconnected. Connect your device from the Pair screen.',
// //         ),
// //         behavior: SnackBarBehavior.floating,
// //       ),
// //     );
// //   }
// // }

// // import 'dart:async';

// // import 'package:coyote_app/components/action_widget.dart';
// // import 'package:coyote_app/components/vacuum_gauge_slider.dart';
// // import 'package:coyote_app/controller/ble_controller.dart';
// // import 'package:flutter/material.dart';
// // import 'package:flutter_svg/svg.dart';
// // import 'package:get/get.dart';
// // import '../theme/app_colors.dart';
// // import '../components/components.dart';

// // /// Full Coyote control screen: Left/Right, circular gauge, Sit/Walk/Run,
// // /// Bluetooth & Battery status, and Turn Off button.
// // class ControlScreen extends StatefulWidget {
// //   const ControlScreen({super.key});

// //   @override
// //   State<ControlScreen> createState() => _ControlScreenState();
// // }

// // class _ControlScreenState extends State<ControlScreen> {
// //   final BleController _bleController = Get.find<BleController>();
// //   int _sideIndex = 0;
// //   int _activityIndex = 0;
// //   int _targetVacuum = 12;
// //   double _actualVacuum = 8.4;

// //   @override
// //   void initState() {
// //     super.initState();
// //     final cached = _bleController.cachedConnectedSideIndex;
// //     if (cached == 0 || cached == 1) {
// //       _sideIndex = cached;
// //     }
// //     // cached == -1 means both or neither were connected last session → default to 0.
// //   }

// //   @override
// //   Widget build(BuildContext context) {
// //     return GetBuilder<BleController>(
// //       init: _bleController,
// //       builder: (_) {
// //         return Scaffold(
// //           body: CoyoteBackground(
// //             child: SafeArea(
// //               child: Padding(
// //                 padding: const EdgeInsets.symmetric(horizontal: 24),
// //                 child: Column(
// //                   crossAxisAlignment: CrossAxisAlignment.stretch,
// //                   children: [
// //                     SizedBox(height: 20),
// //                     _buildHeader(),
// //                     const SizedBox(height: 28),
// //                     SegmentedControl<String>(
// //                       options: [
// //                         SegmentOption(
// //                           label: 'Left',
// //                           imageUri: _sideIndex == 0
// //                               ? "assets/images/left_white.svg"
// //                               : "assets/images/left_grey.svg",
// //                           isConnected: true,
// //                         ),
// //                         SegmentOption(
// //                           label: 'Right',
// //                           imageUri: _sideIndex == 1
// //                               ? "assets/images/right_white.svg"
// //                               : "assets/images/right_grey.svg",
// //                           isConnected: true,
// //                         ),
// //                       ],
// //                       selectedIndex: _sideIndex,
// //                       onChanged: (i) => setState(() => _sideIndex = i),
// //                     ),
// //                     const SizedBox(height: 20),

// //                     Expanded(
// //                       child:
// //                           _bleController.isConnected(
// //                             deviceSide: _sideIndex == 0
// //                                 ? DeviceSide.left
// //                                 : DeviceSide.right,
// //                           )
// //                           ? VacuumGaugeSlider(
// //                               minValue: 0,
// //                               maxValue: 20,
// //                               currentValue: _bleController
// //                                   .getCurrentPressure(
// //                                     _sideIndex == 0
// //                                         ? DeviceSide.left
// //                                         : DeviceSide.right,
// //                                   )
// //                                   .toDouble(),
// //                               targetValue: _bleController
// //                                   .getTargetPressure(
// //                                     _sideIndex == 0
// //                                         ? DeviceSide.left
// //                                         : DeviceSide.right,
// //                                   )
// //                                   .toDouble(),
// //                               onChanged: (value) async {
// //                                 final side = _sideIndex == 0
// //                                     ? DeviceSide.left
// //                                     : DeviceSide.right;
// //                                 _bleController.removePreset(side);
// //                                 _bleController.setGuage(
// //                                   pressure: value.toInt(),
// //                                   deviceSide: side,
// //                                 );
// //                               },
// //                             )
// //                           : SvgPicture.asset("assets/images/value_bar.svg"),
// //                     ),
// //                     Container(
// //                       height: 58,

// //                       decoration: BoxDecoration(
// //                         color: AppColors.segmentContainer,
// //                         borderRadius: BorderRadius.circular(12),
// //                         boxShadow: [
// //                           BoxShadow(
// //                             color: Colors.black.withValues(alpha: 0.2),
// //                             blurRadius: 4,
// //                             offset: const Offset(0, 1),
// //                           ),
// //                         ],
// //                       ),
// //                       child: Row(
// //                         // mainAxisAlignment: MainAxisAlignment.spaceBetween,
// //                         children: [
// //                           ActionWidget(
// //                             imageUri:
// //                                 _bleController.getSelectedPreset(
// //                                           _sideIndex == 0
// //                                               ? DeviceSide.left
// //                                               : DeviceSide.right,
// //                                         ) ==
// //                                         Presets.sit &&
// //                                     _bleController.isConnected(
// //                                       deviceSide: _sideIndex == 0
// //                                           ? DeviceSide.left
// //                                           : DeviceSide.right,
// //                                     )
// //                                 ? "assets/images/sit_white.svg"
// //                                 : "assets/images/sit_grey.svg",
// //                             label: "Sit",
// //                             isSelected:
// //                                 _bleController.getSelectedPreset(
// //                                       _sideIndex == 0
// //                                           ? DeviceSide.left
// //                                           : DeviceSide.right,
// //                                     ) ==
// //                                     Presets.sit &&
// //                                 _bleController.isConnected(
// //                                   deviceSide: _sideIndex == 0
// //                                       ? DeviceSide.left
// //                                       : DeviceSide.right,
// //                                 ),
// //                             onPress: () => _onPresetPressed(Presets.sit),
// //                           ),
// //                           ActionWidget(
// //                             imageUri:
// //                                 _bleController.getSelectedPreset(
// //                                           _sideIndex == 0
// //                                               ? DeviceSide.left
// //                                               : DeviceSide.right,
// //                                         ) ==
// //                                         Presets.walk &&
// //                                     _bleController.isConnected(
// //                                       deviceSide: _sideIndex == 0
// //                                           ? DeviceSide.left
// //                                           : DeviceSide.right,
// //                                     )
// //                                 ? "assets/images/walk_white.svg"
// //                                 : "assets/images/walk_grey.svg",
// //                             label: "Walk",
// //                             isSelected:
// //                                 _bleController.getSelectedPreset(
// //                                       _sideIndex == 0
// //                                           ? DeviceSide.left
// //                                           : DeviceSide.right,
// //                                     ) ==
// //                                     Presets.walk &&
// //                                 _bleController.isConnected(
// //                                   deviceSide: _sideIndex == 0
// //                                       ? DeviceSide.left
// //                                       : DeviceSide.right,
// //                                 ),
// //                             onPress: () => _onPresetPressed(Presets.walk),
// //                           ),
// //                           ActionWidget(
// //                             imageUri:
// //                                 _bleController.getSelectedPreset(
// //                                           _sideIndex == 0
// //                                               ? DeviceSide.left
// //                                               : DeviceSide.right,
// //                                         ) ==
// //                                         Presets.run &&
// //                                     _bleController.isConnected(
// //                                       deviceSide: _sideIndex == 0
// //                                           ? DeviceSide.left
// //                                           : DeviceSide.right,
// //                                     )
// //                                 ? "assets/images/run_white.svg"
// //                                 : "assets/images/run_grey.svg",
// //                             label: "Run",
// //                             isSelected:
// //                                 _bleController.getSelectedPreset(
// //                                       _sideIndex == 0
// //                                           ? DeviceSide.left
// //                                           : DeviceSide.right,
// //                                     ) ==
// //                                     Presets.run &&
// //                                 _bleController.isConnected(
// //                                   deviceSide: _sideIndex == 0
// //                                       ? DeviceSide.left
// //                                       : DeviceSide.right,
// //                                 ),
// //                             onPress: () => _onPresetPressed(Presets.run),
// //                           ),
// //                         ],
// //                       ),
// //                     ),

// //                     const SizedBox(height: 32),
// //                     SizedBox(
// //                       height: 76,
// //                       child: Row(
// //                         children: [
// //                           Expanded(
// //                             child: StatusCard(
// //                               title: 'Bluetooth',
// //                               isConnected: _bleController.isConnected(
// //                                 deviceSide: _sideIndex == 0
// //                                     ? DeviceSide.left
// //                                     : DeviceSide.right,
// //                               ),
// //                               subtitle:
// //                                   _bleController.isConnected(
// //                                     deviceSide: _sideIndex == 0
// //                                         ? DeviceSide.left
// //                                         : DeviceSide.right,
// //                                   )
// //                                   ? 'Connected'
// //                                   : "Disconnected",
// //                               imageUri: "assets/images/bluetooth.svg",
// //                               onTap: _onBluetoothTap,
// //                             ),
// //                           ),
// //                           const SizedBox(width: 8),
// //                           Expanded(
// //                             child: StatusCard(
// //                               title: 'Battery',
// //                               isConnected: _bleController.isConnected(
// //                                 deviceSide: _sideIndex == 0
// //                                     ? DeviceSide.left
// //                                     : DeviceSide.right,
// //                               ),
// //                               imageUri: "assets/images/battery.svg",
// //                               trailing:
// //                                   _bleController.isConnected(
// //                                     deviceSide: _sideIndex == 0
// //                                         ? DeviceSide.left
// //                                         : DeviceSide.right,
// //                                   )
// //                                   ? Row(
// //                                       mainAxisSize: MainAxisSize.min,
// //                                       children: [
// //                                         if (_bleController
// //                                                 .getBatteryInfo(
// //                                                   _sideIndex == 0
// //                                                       ? DeviceSide.left
// //                                                       : DeviceSide.right,
// //                                                 )
// //                                                 .chargingStatus ==
// //                                             1) ...[
// //                                           Icon(
// //                                             Icons.bolt,
// //                                             size: 18,
// //                                             color: AppColors.success,
// //                                           ),
// //                                           const SizedBox(width: 4),
// //                                         ],
// //                                         Text(
// //                                           '${_bleController.getBatteryInfo(_sideIndex == 0 ? DeviceSide.left : DeviceSide.right).batteryPercentage.toStringAsFixed(0)}%',
// //                                           style: const TextStyle(
// //                                             fontSize: 15,
// //                                             fontWeight: FontWeight.w600,
// //                                             color: AppColors.success,
// //                                           ),
// //                                         ),
// //                                       ],
// //                                     )
// //                                   : Container(),
// //                               onTap: _onBatteryTap,
// //                             ),
// //                           ),
// //                         ],
// //                       ),
// //                     ),
// //                     const SizedBox(height: 8),
// //                     PrimaryActionButton(
// //                       label:
// //                           _bleController.getPumpStatus(
// //                                 _sideIndex == 0
// //                                     ? DeviceSide.left
// //                                     : DeviceSide.right,
// //                               ) ==
// //                               1
// //                           ? 'Turn Off'
// //                           : 'Turn On',
// //                       icon: Icons.power_settings_new,
// //                       onPressed: _onTurnOff,
// //                       isOn:
// //                           _bleController.getPumpStatus(
// //                             _sideIndex == 0
// //                                 ? DeviceSide.left
// //                                 : DeviceSide.right,
// //                           ) ==
// //                           1,
// //                     ),
// //                     // const SizedBox(height: 20),
// //                   ],
// //                 ),
// //               ),
// //             ),
// //           ),
// //         );
// //       },
// //     );
// //   }

// //   Widget _buildHeader() {
// //     return Row(
// //       children: [
// //         SvgPicture.asset("assets/images/logo.svg"),
// //         // Text(
// //         //   'Coyote',
// //         //   style: TextStyle(
// //         //     fontSize: 24,
// //         //     fontWeight: FontWeight.bold,
// //         //     color: AppColors.textPrimary,
// //         //   ),
// //         // ),
// //         // const SizedBox(width: 4),
// //         // Icon(Icons.pets, color: AppColors.textPrimary, size: 26),
// //       ],
// //     );
// //   }

// //   void _onBluetoothTap() {
// //     // TODO: Open Bluetooth settings or status
// //   }

// //   void _onPresetPressed(Presets preset) {
// //     final side = _sideIndex == 0 ? DeviceSide.left : DeviceSide.right;
// //     if (!_bleController.isConnected(deviceSide: side)) {
// //       _showDisconnectedSnackBar(context);
// //       return;
// //     }
// //     _bleController.ApplyPreset(deviceSide: side, preset: preset);
// //   }

// //   void _onBatteryTap() async {
// //     final side = _sideIndex == 0 ? DeviceSide.left : DeviceSide.right;

// //     if (!_bleController.isConnected(deviceSide: side)) {
// //       _showDisconnectedSnackBar(context);
// //       return;
// //     }

// //     await _bleController.sendMessage(deviceSide: side, message: "7");
// //     if (!context.mounted) return;
// //     _showInfoDialog(context);
// //   }

// //   void _showInfoDialog(BuildContext context) {
// //     final side = _sideIndex == 0 ? DeviceSide.left : DeviceSide.right;
// //     final battery = _bleController.getBatteryInfo(side);
// //     showDialog(
// //       context: context,
// //       builder: (BuildContext context) {
// //         return AlertDialog(
// //           title: const Text('Battery Information'),
// //           content: Column(
// //             mainAxisSize: MainAxisSize.min,
// //             crossAxisAlignment: CrossAxisAlignment.start,
// //             children: [
// //               Text(
// //                 "Charging Status:  ${battery.chargingStatus == 1 ? "Charging" : "Not Charging"}",
// //               ),
// //               const SizedBox(height: 8),
// //               Text('Battery Percentage: ${battery.batteryPercentage}'),
// //               const SizedBox(height: 8),
// //               Text('Battery Voltage: ${battery.batteryVoltage}'),
// //             ],
// //           ),
// //           actions: [
// //             TextButton(
// //               onPressed: () => Navigator.of(context).pop(),
// //               child: const Text('Close'),
// //             ),
// //           ],
// //         );
// //       },
// //     );
// //   }

// //   void _onTurnOff() async {
// //     final side = _sideIndex == 0 ? DeviceSide.left : DeviceSide.right;

// //     if (!_bleController.isConnected(deviceSide: side)) {
// //       _showDisconnectedSnackBar(context);
// //       return;
// //     }

// //     await _bleController.sendMessage(
// //       message: _bleController.getPumpStatus(side) == 1 ? "2" : "1",
// //       deviceSide: side,
// //     );
// //   }

// //   void _showDisconnectedSnackBar(BuildContext context) {
// //     if (!context.mounted) return;
// //     ScaffoldMessenger.of(context).showSnackBar(
// //       const SnackBar(
// //         content: Text(
// //           'Device disconnected. Connect your device from the Pair screen.',
// //         ),
// //         behavior: SnackBarBehavior.floating,
// //       ),
// //     );
// //   }
// // }

// import 'dart:async';

// import 'package:coyote_app/components/action_widget.dart';
// import 'package:coyote_app/components/vacuum_gauge_slider.dart';
// import 'package:coyote_app/controller/ble_controller.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter_svg/svg.dart';
// import 'package:get/get.dart';
// import '../theme/app_colors.dart';
// import '../components/components.dart';

// /// Full Coyote control screen: Left/Right, circular gauge, Sit/Walk/Run,
// /// Bluetooth & Battery status, and Turn Off button.
// class ControlScreen extends StatefulWidget {
//   const ControlScreen({super.key});

//   @override
//   State<ControlScreen> createState() => _ControlScreenState();
// }

// class _ControlScreenState extends State<ControlScreen> {
//   final BleController _bleController = Get.find<BleController>();
//   int _sideIndex = 0;
//   int _activityIndex = 0;
//   int _targetVacuum = 12;
//   double _actualVacuum = 8.4;

//   @override
//   Widget build(BuildContext context) {
//     return GetBuilder<BleController>(
//       init: _bleController,
//       builder: (_) {
//         return Scaffold(
//           body: CoyoteBackground(
//             child: SafeArea(
//               child: Padding(
//                 padding: const EdgeInsets.symmetric(horizontal: 24),
//                 child: Column(
//                   crossAxisAlignment: CrossAxisAlignment.stretch,
//                   children: [
//                     SizedBox(height: 20),
//                     _buildHeader(),
//                     const SizedBox(height: 28),
//                     SegmentedControl<String>(
//                       options: [
//                         SegmentOption(
//                           label: 'Left',
//                           imageUri: _sideIndex == 0
//                               ? "assets/images/left_white.svg"
//                               : "assets/images/left_grey.svg",
//                           isConnected: true,
//                         ),
//                         SegmentOption(
//                           label: 'Right',
//                           imageUri: _sideIndex == 1
//                               ? "assets/images/right_white.svg"
//                               : "assets/images/right_grey.svg",
//                           isConnected: true,
//                         ),
//                       ],
//                       selectedIndex: _sideIndex,
//                       onChanged: (i) => setState(() => _sideIndex = i),
//                     ),
//                     const SizedBox(height: 20),

//                     Expanded(
//                       child:
//                           _bleController.isConnected(
//                             deviceSide: _sideIndex == 0
//                                 ? DeviceSide.left
//                                 : DeviceSide.right,
//                           )
//                           ? Align(
//                               alignment: Alignment.center,
//                               child: VacuumGaugeSlider(
//                                 minValue: 0,
//                                 maxValue: 20,
//                                 currentValue: _bleController
//                                     .getCurrentPressure(
//                                       _sideIndex == 0
//                                           ? DeviceSide.left
//                                           : DeviceSide.right,
//                                     )
//                                     .toDouble(),
//                                 targetValue: _bleController
//                                     .getTargetPressure(
//                                       _sideIndex == 0
//                                           ? DeviceSide.left
//                                           : DeviceSide.right,
//                                     )
//                                     .toDouble(),
//                                 onChanged: (value) async {
//                                   final side = _sideIndex == 0
//                                       ? DeviceSide.left
//                                       : DeviceSide.right;
//                                   _bleController.removePreset(side);
//                                   _bleController.setGuage(
//                                     pressure: value.toInt(),
//                                     deviceSide: side,
//                                   );
//                                 },
//                               ),
//                             )
//                           : SvgPicture.asset("assets/images/value_bar.svg"),
//                     ),
//                     Container(
//                       height: 58,

//                       decoration: BoxDecoration(
//                         color: AppColors.segmentContainer,
//                         borderRadius: BorderRadius.circular(12),
//                         boxShadow: [
//                           BoxShadow(
//                             color: Colors.black.withValues(alpha: 0.2),
//                             blurRadius: 4,
//                             offset: const Offset(0, 1),
//                           ),
//                         ],
//                       ),
//                       child: Row(
//                         // mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                         children: [
//                           ActionWidget(
//                             imageUri:
//                                 _bleController.getSelectedPreset(
//                                           _sideIndex == 0
//                                               ? DeviceSide.left
//                                               : DeviceSide.right,
//                                         ) ==
//                                         Presets.sit &&
//                                     _bleController.isConnected(
//                                       deviceSide: _sideIndex == 0
//                                           ? DeviceSide.left
//                                           : DeviceSide.right,
//                                     )
//                                 ? "assets/images/sit_white.svg"
//                                 : "assets/images/sit_grey.svg",
//                             label: "Sit",
//                             isSelected:
//                                 _bleController.getSelectedPreset(
//                                       _sideIndex == 0
//                                           ? DeviceSide.left
//                                           : DeviceSide.right,
//                                     ) ==
//                                     Presets.sit &&
//                                 _bleController.isConnected(
//                                   deviceSide: _sideIndex == 0
//                                       ? DeviceSide.left
//                                       : DeviceSide.right,
//                                 ),
//                             onPress: () => _onPresetPressed(Presets.sit),
//                           ),
//                           ActionWidget(
//                             imageUri:
//                                 _bleController.getSelectedPreset(
//                                           _sideIndex == 0
//                                               ? DeviceSide.left
//                                               : DeviceSide.right,
//                                         ) ==
//                                         Presets.walk &&
//                                     _bleController.isConnected(
//                                       deviceSide: _sideIndex == 0
//                                           ? DeviceSide.left
//                                           : DeviceSide.right,
//                                     )
//                                 ? "assets/images/walk_white.svg"
//                                 : "assets/images/walk_grey.svg",
//                             label: "Walk",
//                             isSelected:
//                                 _bleController.getSelectedPreset(
//                                       _sideIndex == 0
//                                           ? DeviceSide.left
//                                           : DeviceSide.right,
//                                     ) ==
//                                     Presets.walk &&
//                                 _bleController.isConnected(
//                                   deviceSide: _sideIndex == 0
//                                       ? DeviceSide.left
//                                       : DeviceSide.right,
//                                 ),
//                             onPress: () => _onPresetPressed(Presets.walk),
//                           ),
//                           ActionWidget(
//                             imageUri:
//                                 _bleController.getSelectedPreset(
//                                           _sideIndex == 0
//                                               ? DeviceSide.left
//                                               : DeviceSide.right,
//                                         ) ==
//                                         Presets.run &&
//                                     _bleController.isConnected(
//                                       deviceSide: _sideIndex == 0
//                                           ? DeviceSide.left
//                                           : DeviceSide.right,
//                                     )
//                                 ? "assets/images/run_white.svg"
//                                 : "assets/images/run_grey.svg",
//                             label: "Run",
//                             isSelected:
//                                 _bleController.getSelectedPreset(
//                                       _sideIndex == 0
//                                           ? DeviceSide.left
//                                           : DeviceSide.right,
//                                     ) ==
//                                     Presets.run &&
//                                 _bleController.isConnected(
//                                   deviceSide: _sideIndex == 0
//                                       ? DeviceSide.left
//                                       : DeviceSide.right,
//                                 ),
//                             onPress: () => _onPresetPressed(Presets.run),
//                           ),
//                         ],
//                       ),
//                     ),

//                     const SizedBox(height: 32),
//                     SizedBox(
//                       height: 76,
//                       child: Row(
//                         children: [
//                           Expanded(
//                             child: StatusCard(
//                               title: 'Bluetooth',
//                               isConnected: _bleController.isConnected(
//                                 deviceSide: _sideIndex == 0
//                                     ? DeviceSide.left
//                                     : DeviceSide.right,
//                               ),
//                               subtitle:
//                                   _bleController.isConnected(
//                                     deviceSide: _sideIndex == 0
//                                         ? DeviceSide.left
//                                         : DeviceSide.right,
//                                   )
//                                   ? 'Connected'
//                                   : "UnConnected",
//                               imageUri: "assets/images/bluetooth.svg",
//                               onTap: _onBluetoothTap,
//                             ),
//                           ),
//                           const SizedBox(width: 8),
//                           Expanded(
//                             child: StatusCard(
//                               title: 'Battery',
//                               isConnected: _bleController.isConnected(
//                                 deviceSide: _sideIndex == 0
//                                     ? DeviceSide.left
//                                     : DeviceSide.right,
//                               ),
//                               imageUri: "assets/images/battery.svg",
//                               trailing:
//                                   _bleController.isConnected(
//                                     deviceSide: _sideIndex == 0
//                                         ? DeviceSide.left
//                                         : DeviceSide.right,
//                                   )
//                                   ? Row(
//                                       mainAxisSize: MainAxisSize.min,
//                                       children: [
//                                         if (_bleController
//                                                 .getBatteryInfo(
//                                                   _sideIndex == 0
//                                                       ? DeviceSide.left
//                                                       : DeviceSide.right,
//                                                 )
//                                                 .chargingStatus ==
//                                             1) ...[
//                                           Icon(
//                                             Icons.bolt,
//                                             size: 18,
//                                             color: AppColors.success,
//                                           ),
//                                           const SizedBox(width: 4),
//                                         ],
//                                         Text(
//                                           '${_bleController.getBatteryInfo(_sideIndex == 0 ? DeviceSide.left : DeviceSide.right).batteryPercentage.toStringAsFixed(0)}%',
//                                           style: const TextStyle(
//                                             fontSize: 15,
//                                             fontWeight: FontWeight.w600,
//                                             color: AppColors.success,
//                                           ),
//                                         ),
//                                       ],
//                                     )
//                                   : Container(),
//                               onTap: _onBatteryTap,
//                             ),
//                           ),
//                         ],
//                       ),
//                     ),
//                     const SizedBox(height: 8),
//                     PrimaryActionButton(
//                       label:
//                           _bleController.getPumpStatus(
//                                 _sideIndex == 0
//                                     ? DeviceSide.left
//                                     : DeviceSide.right,
//                               ) ==
//                               1
//                           ? 'Turn Off'
//                           : 'Turn On',
//                       icon: Icons.power_settings_new,
//                       onPressed: _onTurnOff,
//                       isOn:
//                           _bleController.getPumpStatus(
//                             _sideIndex == 0
//                                 ? DeviceSide.left
//                                 : DeviceSide.right,
//                           ) ==
//                           1,
//                     ),
//                     // const SizedBox(height: 20),
//                   ],
//                 ),
//               ),
//             ),
//           ),
//         );
//       },
//     );
//   }

//   Widget _buildHeader() {
//     return Row(
//       children: [
//         SvgPicture.asset("assets/images/logo.svg"),
//         // Text(
//         //   'Coyote',
//         //   style: TextStyle(
//         //     fontSize: 24,
//         //     fontWeight: FontWeight.bold,
//         //     color: AppColors.textPrimary,
//         //   ),
//         // ),
//         // const SizedBox(width: 4),
//         // Icon(Icons.pets, color: AppColors.textPrimary, size: 26),
//       ],
//     );
//   }

//   void _onBluetoothTap() {
//     // TODO: Open Bluetooth settings or status
//   }

//   void _onPresetPressed(Presets preset) {
//     final side = _sideIndex == 0 ? DeviceSide.left : DeviceSide.right;
//     if (!_bleController.isConnected(deviceSide: side)) {
//       _showDisconnectedSnackBar(context);
//       return;
//     }
//     _bleController.ApplyPreset(deviceSide: side, preset: preset);
//   }

//   void _onBatteryTap() async {
//     final side = _sideIndex == 0 ? DeviceSide.left : DeviceSide.right;

//     if (!_bleController.isConnected(deviceSide: side)) {
//       _showDisconnectedSnackBar(context);
//       return;
//     }

//     await _bleController.sendMessage(deviceSide: side, message: "7");
//     if (!context.mounted) return;
//     _showInfoDialog(context);
//   }

//   void _showInfoDialog(BuildContext context) {
//     final side = _sideIndex == 0 ? DeviceSide.left : DeviceSide.right;
//     final battery = _bleController.getBatteryInfo(side);
//     showDialog(
//       context: context,
//       builder: (BuildContext context) {
//         return AlertDialog(
//           title: const Text('Battery Information'),
//           content: Column(
//             mainAxisSize: MainAxisSize.min,
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: [
//               Text(
//                 "Charging Status:  ${battery.chargingStatus == 1 ? "Charging" : "Not Charging"}",
//               ),
//               const SizedBox(height: 8),
//               Text('Battery Percentage: ${battery.batteryPercentage}'),
//               const SizedBox(height: 8),
//               Text('Battery Voltage: ${battery.batteryVoltage}'),
//             ],
//           ),
//           actions: [
//             TextButton(
//               onPressed: () => Navigator.of(context).pop(),
//               child: const Text('Close'),
//             ),
//           ],
//         );
//       },
//     );
//   }

//   void _onTurnOff() async {
//     final side = _sideIndex == 0 ? DeviceSide.left : DeviceSide.right;

//     if (!_bleController.isConnected(deviceSide: side)) {
//       _showDisconnectedSnackBar(context);
//       return;
//     }

//     await _bleController.sendMessage(
//       message: _bleController.getPumpStatus(side) == 1 ? "2" : "1",
//       deviceSide: side,
//     );
//   }

//   void _showDisconnectedSnackBar(BuildContext context) {
//     if (!context.mounted) return;
//     final messenger = ScaffoldMessenger.of(context);
//     messenger.clearSnackBars();
//     messenger.showSnackBar(
//       const SnackBar(
//         content: Text(
//           'Device disconnected. Connect your device from the Pair screen.',
//         ),
//         behavior: SnackBarBehavior.floating,
//       ),
//     );
//   }
// }

// import 'dart:async';

// import 'package:coyote_app/components/action_widget.dart';
// import 'package:coyote_app/components/vacuum_gauge_slider.dart';
// import 'package:coyote_app/controller/ble_controller.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter_svg/svg.dart';
// import 'package:get/get.dart';
// import '../theme/app_colors.dart';
// import '../components/components.dart';

// /// Full Coyote control screen: Left/Right, circular gauge, Sit/Walk/Run,
// /// Bluetooth & Battery status, and Turn Off button.
// class ControlScreen extends StatefulWidget {
//   const ControlScreen({super.key});

//   @override
//   State<ControlScreen> createState() => _ControlScreenState();
// }

// class _ControlScreenState extends State<ControlScreen> {
//   final BleController _bleController = Get.find<BleController>();
//   int _activityIndex = 0;
//   int _targetVacuum = 12;
//   double _actualVacuum = 8.4;

//   @override
//   Widget build(BuildContext context) {
//     return GetBuilder<BleController>(
//       init: _bleController,
//       builder: (_) {
//         return Scaffold(
//           body: CoyoteBackground(
//             child: SafeArea(
//               child: Padding(
//                 padding: const EdgeInsets.symmetric(horizontal: 24),
//                 child: Column(
//                   crossAxisAlignment: CrossAxisAlignment.stretch,
//                   children: [
//                     SizedBox(height: 20),
//                     _buildHeader(),
//                     const SizedBox(height: 28),
//                     SegmentedControl<String>(
//                       options: [
//                         SegmentOption(
//                           label: 'Left',
//                           imageUri: _sideIndex == 0
//                               ? "assets/images/left_white.svg"
//                               : "assets/images/left_grey.svg",
//                           isConnected: true,
//                         ),
//                         SegmentOption(
//                           label: 'Right',
//                           imageUri: _sideIndex == 1
//                               ? "assets/images/right_white.svg"
//                               : "assets/images/right_grey.svg",
//                           isConnected: true,
//                         ),
//                       ],
//                       selectedIndex: _sideIndex,
//                       onChanged: (i) => setState(() => _sideIndex = i),
//                     ),
//                     const SizedBox(height: 20),

//                     Expanded(
//                       child:
//                           _bleController.isConnected(
//                             deviceSide: _sideIndex == 0
//                                 ? DeviceSide.left
//                                 : DeviceSide.right,
//                           )
//                           ? VacuumGaugeSlider(
//                               minValue: 0,
//                               maxValue: 20,
//                               currentValue: _bleController
//                                   .getCurrentPressure(
//                                     _sideIndex == 0
//                                         ? DeviceSide.left
//                                         : DeviceSide.right,
//                                   )
//                                   .toDouble(),
//                               targetValue: _bleController
//                                   .getTargetPressure(
//                                     _sideIndex == 0
//                                         ? DeviceSide.left
//                                         : DeviceSide.right,
//                                   )
//                                   .toDouble(),
//                               onChanged: (value) async {
//                                 final side = _sideIndex == 0
//                                     ? DeviceSide.left
//                                     : DeviceSide.right;
//                                 _bleController.removePreset(side);
//                                 _bleController.setGuage(
//                                   pressure: value.toInt(),
//                                   deviceSide: side,
//                                 );
//                               },
//                             )
//                           : SvgPicture.asset("assets/images/value_bar.svg"),
//                     ),
//                     Container(
//                       height: 58,

//                       decoration: BoxDecoration(
//                         color: AppColors.segmentContainer,
//                         borderRadius: BorderRadius.circular(12),
//                         boxShadow: [
//                           BoxShadow(
//                             color: Colors.black.withValues(alpha: 0.2),
//                             blurRadius: 4,
//                             offset: const Offset(0, 1),
//                           ),
//                         ],
//                       ),
//                       child: Row(
//                         // mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                         children: [
//                           ActionWidget(
//                             imageUri:
//                                 _bleController.getSelectedPreset(
//                                           _sideIndex == 0
//                                               ? DeviceSide.left
//                                               : DeviceSide.right,
//                                         ) ==
//                                         Presets.sit &&
//                                     _bleController.isConnected(
//                                       deviceSide: _sideIndex == 0
//                                           ? DeviceSide.left
//                                           : DeviceSide.right,
//                                     )
//                                 ? "assets/images/sit_white.svg"
//                                 : "assets/images/sit_grey.svg",
//                             label: "Sit",
//                             isSelected:
//                                 _bleController.getSelectedPreset(
//                                       _sideIndex == 0
//                                           ? DeviceSide.left
//                                           : DeviceSide.right,
//                                     ) ==
//                                     Presets.sit &&
//                                 _bleController.isConnected(
//                                   deviceSide: _sideIndex == 0
//                                       ? DeviceSide.left
//                                       : DeviceSide.right,
//                                 ),
//                             onPress: () => _onPresetPressed(Presets.sit),
//                           ),
//                           ActionWidget(
//                             imageUri:
//                                 _bleController.getSelectedPreset(
//                                           _sideIndex == 0
//                                               ? DeviceSide.left
//                                               : DeviceSide.right,
//                                         ) ==
//                                         Presets.walk &&
//                                     _bleController.isConnected(
//                                       deviceSide: _sideIndex == 0
//                                           ? DeviceSide.left
//                                           : DeviceSide.right,
//                                     )
//                                 ? "assets/images/walk_white.svg"
//                                 : "assets/images/walk_grey.svg",
//                             label: "Walk",
//                             isSelected:
//                                 _bleController.getSelectedPreset(
//                                       _sideIndex == 0
//                                           ? DeviceSide.left
//                                           : DeviceSide.right,
//                                     ) ==
//                                     Presets.walk &&
//                                 _bleController.isConnected(
//                                   deviceSide: _sideIndex == 0
//                                       ? DeviceSide.left
//                                       : DeviceSide.right,
//                                 ),
//                             onPress: () => _onPresetPressed(Presets.walk),
//                           ),
//                           ActionWidget(
//                             imageUri:
//                                 _bleController.getSelectedPreset(
//                                           _sideIndex == 0
//                                               ? DeviceSide.left
//                                               : DeviceSide.right,
//                                         ) ==
//                                         Presets.run &&
//                                     _bleController.isConnected(
//                                       deviceSide: _sideIndex == 0
//                                           ? DeviceSide.left
//                                           : DeviceSide.right,
//                                     )
//                                 ? "assets/images/run_white.svg"
//                                 : "assets/images/run_grey.svg",
//                             label: "Run",
//                             isSelected:
//                                 _bleController.getSelectedPreset(
//                                       _sideIndex == 0
//                                           ? DeviceSide.left
//                                           : DeviceSide.right,
//                                     ) ==
//                                     Presets.run &&
//                                 _bleController.isConnected(
//                                   deviceSide: _sideIndex == 0
//                                       ? DeviceSide.left
//                                       : DeviceSide.right,
//                                 ),
//                             onPress: () => _onPresetPressed(Presets.run),
//                           ),
//                         ],
//                       ),
//                     ),

//                     const SizedBox(height: 32),
//                     SizedBox(
//                       height: 76,
//                       child: Row(
//                         children: [
//                           Expanded(
//                             child: StatusCard(
//                               title: 'Bluetooth',
//                               isConnected: _bleController.isConnected(
//                                 deviceSide: _sideIndex == 0
//                                     ? DeviceSide.left
//                                     : DeviceSide.right,
//                               ),
//                               subtitle:
//                                   _bleController.isConnected(
//                                     deviceSide: _sideIndex == 0
//                                         ? DeviceSide.left
//                                         : DeviceSide.right,
//                                   )
//                                   ? 'Connected'
//                                   : "Disconnected",
//                               imageUri: "assets/images/bluetooth.svg",
//                               onTap: _onBluetoothTap,
//                             ),
//                           ),
//                           const SizedBox(width: 8),
//                           Expanded(
//                             child: StatusCard(
//                               title: 'Battery',
//                               isConnected: _bleController.isConnected(
//                                 deviceSide: _sideIndex == 0
//                                     ? DeviceSide.left
//                                     : DeviceSide.right,
//                               ),
//                               imageUri: "assets/images/battery.svg",
//                               trailing:
//                                   _bleController.isConnected(
//                                     deviceSide: _sideIndex == 0
//                                         ? DeviceSide.left
//                                         : DeviceSide.right,
//                                   )
//                                   ? Row(
//                                       mainAxisSize: MainAxisSize.min,
//                                       children: [
//                                         if (_bleController
//                                                 .getBatteryInfo(
//                                                   _sideIndex == 0
//                                                       ? DeviceSide.left
//                                                       : DeviceSide.right,
//                                                 )
//                                                 .chargingStatus ==
//                                             1) ...[
//                                           Icon(
//                                             Icons.bolt,
//                                             size: 18,
//                                             color: AppColors.success,
//                                           ),
//                                           const SizedBox(width: 4),
//                                         ],
//                                         Text(
//                                           '${_bleController.getBatteryInfo(_sideIndex == 0 ? DeviceSide.left : DeviceSide.right).batteryPercentage.toStringAsFixed(0)}%',
//                                           style: const TextStyle(
//                                             fontSize: 15,
//                                             fontWeight: FontWeight.w600,
//                                             color: AppColors.success,
//                                           ),
//                                         ),
//                                       ],
//                                     )
//                                   : Container(),
//                               onTap: _onBatteryTap,
//                             ),
//                           ),
//                         ],
//                       ),
//                     ),
//                     const SizedBox(height: 8),
//                     PrimaryActionButton(
//                       label:
//                           _bleController.getPumpStatus(
//                                 _sideIndex == 0
//                                     ? DeviceSide.left
//                                     : DeviceSide.right,
//                               ) ==
//                               1
//                           ? 'Turn Off'
//                           : 'Turn On',
//                       icon: Icons.power_settings_new,
//                       onPressed: _onTurnOff,
//                       isOn:
//                           _bleController.getPumpStatus(
//                             _sideIndex == 0
//                                 ? DeviceSide.left
//                                 : DeviceSide.right,
//                           ) ==
//                           1,
//                     ),
//                     // const SizedBox(height: 20),
//                   ],
//                 ),
//               ),
//             ),
//           ),
//         );
//       },
//     );
//   }

//   Widget _buildHeader() {
//     return Row(
//       children: [
//         SvgPicture.asset("assets/images/logo.svg"),
//         // Text(
//         //   'Coyote',
//         //   style: TextStyle(
//         //     fontSize: 24,
//         //     fontWeight: FontWeight.bold,
//         //     color: AppColors.textPrimary,
//         //   ),
//         // ),
//         // const SizedBox(width: 4),
//         // Icon(Icons.pets, color: AppColors.textPrimary, size: 26),
//       ],
//     );
//   }

//   void _onBluetoothTap() {
//     // TODO: Open Bluetooth settings or status
//   }

//   void _onPresetPressed(Presets preset) {
//     final side = _sideIndex == 0 ? DeviceSide.left : DeviceSide.right;
//     if (!_bleController.isConnected(deviceSide: side)) {
//       _showDisconnectedSnackBar(context);
//       return;
//     }
//     _bleController.ApplyPreset(deviceSide: side, preset: preset);
//   }

//   void _onBatteryTap() async {
//     final side = _sideIndex == 0 ? DeviceSide.left : DeviceSide.right;

//     if (!_bleController.isConnected(deviceSide: side)) {
//       _showDisconnectedSnackBar(context);
//       return;
//     }

//     await _bleController.sendMessage(deviceSide: side, message: "7");
//     if (!context.mounted) return;
//     _showInfoDialog(context);
//   }

//   void _showInfoDialog(BuildContext context) {
//     final side = _sideIndex == 0 ? DeviceSide.left : DeviceSide.right;
//     final battery = _bleController.getBatteryInfo(side);
//     showDialog(
//       context: context,
//       builder: (BuildContext context) {
//         return AlertDialog(
//           title: const Text('Battery Information'),
//           content: Column(
//             mainAxisSize: MainAxisSize.min,
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: [
//               Text(
//                 "Charging Status:  ${battery.chargingStatus == 1 ? "Charging" : "Not Charging"}",
//               ),
//               const SizedBox(height: 8),
//               Text('Battery Percentage: ${battery.batteryPercentage}'),
//               const SizedBox(height: 8),
//               Text('Battery Voltage: ${battery.batteryVoltage}'),
//             ],
//           ),
//           actions: [
//             TextButton(
//               onPressed: () => Navigator.of(context).pop(),
//               child: const Text('Close'),
//             ),
//           ],
//         );
//       },
//     );
//   }

//   void _onTurnOff() async {
//     final side = _sideIndex == 0 ? DeviceSide.left : DeviceSide.right;

//     if (!_bleController.isConnected(deviceSide: side)) {
//       _showDisconnectedSnackBar(context);
//       return;
//     }

//     await _bleController.sendMessage(
//       message: _bleController.getPumpStatus(side) == 1 ? "2" : "1",
//       deviceSide: side,
//     );
//   }

//   void _showDisconnectedSnackBar(BuildContext context) {
//     if (!context.mounted) return;
//     ScaffoldMessenger.of(context).showSnackBar(
//       const SnackBar(
//         content: Text(
//           'Device disconnected. Connect your device from the Pair screen.',
//         ),
//         behavior: SnackBarBehavior.floating,
//       ),
//     );
//   }
// }

import 'dart:async';

import 'package:coyote_app/components/action_widget.dart';
import 'package:coyote_app/components/vacuum_gauge_slider.dart';
import 'package:coyote_app/controller/ble_controller.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import '../theme/app_colors.dart';
import '../components/components.dart';

/// Full Coyote control screen: Left/Right, circular gauge, Sit/Walk/Run,
/// Bluetooth & Battery status, and Turn Off button.
class ControlScreen extends StatefulWidget {
  const ControlScreen({super.key});

  @override
  State<ControlScreen> createState() => _ControlScreenState();
}

class _ControlScreenState extends State<ControlScreen> {
  final BleController _bleController = Get.find<BleController>();
  int _activityIndex = 0;
  int _targetVacuum = 12;
  double _actualVacuum = 8.4;

  @override
  Widget build(BuildContext context) {
    return GetBuilder<BleController>(
      init: _bleController,
      builder: (_) {
        return Scaffold(
          body: CoyoteBackground(
            child: SafeArea(
              child: LayoutBuilder(
                builder: (context, constraints) {
                  final width = constraints.maxWidth;
                  final height = constraints.maxHeight;
                  final scale = (width / 393).clamp(0.84, 1.18);

                  final horizontalPadding = (24 * scale)
                      .clamp(16, 32)
                      .toDouble();
                  final gapTop = (20 * scale).toDouble();
                  final gapAfterHeader = (28 * scale).toDouble();
                  final gapAfterSideSegment = (20 * scale).toDouble();
                  final gapAfterActions = (32 * scale).toDouble();
                  final gapBeforeButton = (8 * scale).toDouble();
                  final statusRowHeight = (76 * scale).clamp(64, 96).toDouble();

                  final minGaugeHeight = (height * 0.34).clamp(180.0, 360.0);

                  return Padding(
                    padding: EdgeInsets.symmetric(
                      horizontal: horizontalPadding,
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        SizedBox(height: gapTop),
                        _buildHeader(),
                        SizedBox(height: gapAfterHeader),
                        SegmentedControl<String>(
                          options: [
                            SegmentOption(
                              label: 'Left',
                              imageUri: _bleController.sideIndex == 0
                                  ? "assets/images/left_white.svg"
                                  : "assets/images/left_grey.svg",
                              isConnected: true,
                            ),
                            SegmentOption(
                              label: 'Right',
                              imageUri: _bleController.sideIndex == 1
                                  ? "assets/images/right_white.svg"
                                  : "assets/images/right_grey.svg",
                              isConnected: true,
                            ),
                          ],
                          selectedIndex: _bleController.sideIndex,
                          onChanged: (i) {
                            _bleController.sideIndex = i;
                            _bleController.update();
                          },
                        ),
                        SizedBox(height: gapAfterSideSegment),
                        Expanded(
                          // flex: 12,
                          child:
                              _bleController.isConnected(
                                deviceSide: _bleController.sideIndex == 0
                                    ? DeviceSide.left
                                    : DeviceSide.right,
                              )
                              ? Align(
                                  alignment: Alignment.center,
                                  child: ConstrainedBox(
                                    constraints: BoxConstraints(
                                      maxHeight: minGaugeHeight,
                                      maxWidth: width,
                                    ),
                                    child: VacuumGaugeSlider(
                                      minValue: 0,
                                      maxValue: 20,
                                      currentValue: _bleController
                                          .getCurrentPressure(
                                            _bleController.sideIndex == 0
                                                ? DeviceSide.left
                                                : DeviceSide.right,
                                          )
                                          .toDouble(),
                                      targetValue: _bleController
                                          .getTargetPressure(
                                            _bleController.sideIndex == 0
                                                ? DeviceSide.left
                                                : DeviceSide.right,
                                          )
                                          .toDouble(),
                                      onChanged: (value) async {
                                        print(value);
                                        final side =
                                            _bleController.sideIndex == 0
                                            ? DeviceSide.left
                                            : DeviceSide.right;
                                        _bleController.removePreset(side);
                                        _bleController.setGuage(
                                          pressure: value.toInt(),
                                          deviceSide: side,
                                        );
                                      },
                                    ),
                                  ),
                                )
                              : Align(
                                  alignment: Alignment.center,
                                  child: SvgPicture.asset(
                                    "assets/images/value_bar.svg",
                                  ),
                                ),
                        ),
                        SizedBox(height: 10),
                        SizedBox(
                          height: (58 * scale).clamp(52, 66).toDouble(),
                          child: Container(
                            decoration: BoxDecoration(
                              color: AppColors.segmentContainer,
                              borderRadius: BorderRadius.circular(12),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withValues(alpha: 0.2),
                                  blurRadius: 4,
                                  offset: const Offset(0, 1),
                                ),
                              ],
                            ),
                            child: Row(
                              children: [
                                ActionWidget(
                                  imageUri:
                                      _bleController.getSelectedPreset(
                                                _bleController.sideIndex == 0
                                                    ? DeviceSide.left
                                                    : DeviceSide.right,
                                              ) ==
                                              Presets.sit &&
                                          _bleController.isConnected(
                                            deviceSide:
                                                _bleController.sideIndex == 0
                                                ? DeviceSide.left
                                                : DeviceSide.right,
                                          )
                                      ? "assets/images/sit_white.svg"
                                      : "assets/images/sit_grey.svg",
                                  label: "Sit",
                                  isSelected:
                                      _bleController.getSelectedPreset(
                                            _bleController.sideIndex == 0
                                                ? DeviceSide.left
                                                : DeviceSide.right,
                                          ) ==
                                          Presets.sit &&
                                      _bleController.isConnected(
                                        deviceSide:
                                            _bleController.sideIndex == 0
                                            ? DeviceSide.left
                                            : DeviceSide.right,
                                      ),
                                  onPress: () => _onPresetPressed(Presets.sit),
                                ),
                                ActionWidget(
                                  imageUri:
                                      _bleController.getSelectedPreset(
                                                _bleController.sideIndex == 0
                                                    ? DeviceSide.left
                                                    : DeviceSide.right,
                                              ) ==
                                              Presets.walk &&
                                          _bleController.isConnected(
                                            deviceSide:
                                                _bleController.sideIndex == 0
                                                ? DeviceSide.left
                                                : DeviceSide.right,
                                          )
                                      ? "assets/images/walk_white.svg"
                                      : "assets/images/walk_grey.svg",
                                  label: "Walk",
                                  isSelected:
                                      _bleController.getSelectedPreset(
                                            _bleController.sideIndex == 0
                                                ? DeviceSide.left
                                                : DeviceSide.right,
                                          ) ==
                                          Presets.walk &&
                                      _bleController.isConnected(
                                        deviceSide:
                                            _bleController.sideIndex == 0
                                            ? DeviceSide.left
                                            : DeviceSide.right,
                                      ),
                                  onPress: () => _onPresetPressed(Presets.walk),
                                ),
                                ActionWidget(
                                  imageUri:
                                      _bleController.getSelectedPreset(
                                                _bleController.sideIndex == 0
                                                    ? DeviceSide.left
                                                    : DeviceSide.right,
                                              ) ==
                                              Presets.run &&
                                          _bleController.isConnected(
                                            deviceSide:
                                                _bleController.sideIndex == 0
                                                ? DeviceSide.left
                                                : DeviceSide.right,
                                          )
                                      ? "assets/images/run_white.svg"
                                      : "assets/images/run_grey.svg",
                                  label: "Run",
                                  isSelected:
                                      _bleController.getSelectedPreset(
                                            _bleController.sideIndex == 0
                                                ? DeviceSide.left
                                                : DeviceSide.right,
                                          ) ==
                                          Presets.run &&
                                      _bleController.isConnected(
                                        deviceSide:
                                            _bleController.sideIndex == 0
                                            ? DeviceSide.left
                                            : DeviceSide.right,
                                      ),
                                  onPress: () => _onPresetPressed(Presets.run),
                                ),
                              ],
                            ),
                          ),
                        ),
                        SizedBox(height: gapAfterActions),
                        SizedBox(
                          height: statusRowHeight,
                          child: Row(
                            children: [
                              Expanded(
                                child: StatusCard(
                                  title: 'Bluetooth',
                                  isConnected: _bleController.isConnected(
                                    deviceSide: _bleController.sideIndex == 0
                                        ? DeviceSide.left
                                        : DeviceSide.right,
                                  ),
                                  subtitle:
                                      _bleController.isConnected(
                                        deviceSide:
                                            _bleController.sideIndex == 0
                                            ? DeviceSide.left
                                            : DeviceSide.right,
                                      )
                                      ? 'Connected'
                                      : "Disconnected",
                                  imageUri: "assets/images/bluetooth.svg",
                                  onTap: _onBluetoothTap,
                                ),
                              ),
                              SizedBox(width: (8 * scale).toDouble()),
                              Expanded(
                                child: StatusCard(
                                  title: 'Battery',
                                  isConnected: _bleController.isConnected(
                                    deviceSide: _bleController.sideIndex == 0
                                        ? DeviceSide.left
                                        : DeviceSide.right,
                                  ),
                                  imageUri: "assets/images/battery.svg",
                                  trailing:
                                      _bleController.isConnected(
                                        deviceSide:
                                            _bleController.sideIndex == 0
                                            ? DeviceSide.left
                                            : DeviceSide.right,
                                      )
                                      ? Row(
                                          mainAxisSize: MainAxisSize.min,
                                          children: [
                                            if (_bleController
                                                    .getBatteryInfo(
                                                      _bleController
                                                                  .sideIndex ==
                                                              0
                                                          ? DeviceSide.left
                                                          : DeviceSide.right,
                                                    )
                                                    .chargingStatus ==
                                                1) ...[
                                              Icon(
                                                Icons.bolt,
                                                size: 18,
                                                color: AppColors.success,
                                              ),
                                              const SizedBox(width: 4),
                                            ],
                                            Text(
                                              '${_bleController.getBatteryInfo(_bleController.sideIndex == 0 ? DeviceSide.left : DeviceSide.right).batteryPercentage.toStringAsFixed(0)}%',
                                              style: const TextStyle(
                                                fontSize: 15,
                                                fontWeight: FontWeight.w600,
                                                color: AppColors.success,
                                              ),
                                            ),
                                          ],
                                        )
                                      : Container(),
                                  onTap: _onBatteryTap,
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(height: gapBeforeButton),
                        PrimaryActionButton(
                          label:
                              _bleController.getPumpStatus(
                                    _bleController.sideIndex == 0
                                        ? DeviceSide.left
                                        : DeviceSide.right,
                                  ) ==
                                  1
                              ? 'Turn Off'
                              : 'Turn On',
                          icon: Icons.power_settings_new,
                          onPressed: _onTurnOff,
                          isOn:
                              _bleController.getPumpStatus(
                                _bleController.sideIndex == 0
                                    ? DeviceSide.left
                                    : DeviceSide.right,
                              ) ==
                              1,
                        ),
                        SizedBox(height: (scale).toDouble()),
                      ],
                    ),
                  );
                },
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildHeader() {
    return Row(
      children: [
        SvgPicture.asset("assets/images/logo.svg"),
        // Text(
        //   'Coyote',
        //   style: TextStyle(
        //     fontSize: 24,
        //     fontWeight: FontWeight.bold,
        //     color: AppColors.textPrimary,
        //   ),
        // ),
        // const SizedBox(width: 4),
        // Icon(Icons.pets, color: AppColors.textPrimary, size: 26),
      ],
    );
  }

  void _onBluetoothTap() {
    // TODO: Open Bluetooth settings or status
  }

  void _onPresetPressed(Presets preset) {
    final side = _bleController.sideIndex == 0
        ? DeviceSide.left
        : DeviceSide.right;
    if (!_bleController.isConnected(deviceSide: side)) {
      _showDisconnectedSnackBar(context);
      return;
    }
    _bleController.ApplyPreset(deviceSide: side, preset: preset);
  }

  void _onBatteryTap() async {
    final side = _bleController.sideIndex == 0
        ? DeviceSide.left
        : DeviceSide.right;

    if (!_bleController.isConnected(deviceSide: side)) {
      _showDisconnectedSnackBar(context);
      return;
    }

    await _bleController.sendMessage(deviceSide: side, message: "7");
    if (!context.mounted) return;
    _showInfoDialog(context);
  }

  void _showInfoDialog(BuildContext context) {
    final side = _bleController.sideIndex == 0
        ? DeviceSide.left
        : DeviceSide.right;
    final battery = _bleController.getBatteryInfo(side);
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Battery Information'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "Charging Status:  ${battery.chargingStatus == 1 ? "Charging" : "Not Charging"}",
              ),
              const SizedBox(height: 8),
              Text('Battery Percentage: ${battery.batteryPercentage}'),
              const SizedBox(height: 8),
              Text('Battery Voltage: ${battery.batteryVoltage}'),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Close'),
            ),
          ],
        );
      },
    );
  }

  void _onTurnOff() async {
    final side = _bleController.sideIndex == 0
        ? DeviceSide.left
        : DeviceSide.right;

    if (!_bleController.isConnected(deviceSide: side)) {
      _showDisconnectedSnackBar(context);
      return;
    }

    await _bleController.sendMessage(
      message: _bleController.getPumpStatus(side) == 1 ? "2" : "1",
      deviceSide: side,
    );
  }

  void _showDisconnectedSnackBar(BuildContext context) {
    if (!context.mounted) return;
    final messenger = ScaffoldMessenger.of(context);
    messenger.clearSnackBars();
    messenger.showSnackBar(
      const SnackBar(
        content: Text(
          'Device disconnected. Connect your device from the Pair screen.',
        ),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }
}
